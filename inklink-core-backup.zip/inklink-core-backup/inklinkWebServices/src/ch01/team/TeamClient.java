package ch01.team;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.logging.Logger;

import javax.xml.namespace.QName;

//import teamClientStubs.Player;
//import teamClientStubs.Team;
//import teamClientStubs.Teams;
//import teamClientStubs.TeamsService;

public class TeamClient {

	private final static Logger logger = Logger.getLogger(TeamClient.class.getName());
	
	public static void main(String args[]) {
		URL url = null;
		try {
			url = new URL("http://localhost:8888/teams?wsdl");
        } catch (MalformedURLException e) {
            logger.warning("Failed to create URL for the wsdl Location: 'http://localhost:8888/teams?wsdl', retrying as a local file");
            logger.warning(e.getMessage());
        }
//		TeamsService service = new TeamsService(url, new QName("http://team.ch01/", "TeamsService"));
//		Teams port = service.getTeamsPort();
//		List <Team> teams = port.getTeams();
//		for(Team team : teams) {
//			System.out.println("Team name: " + team.getName() + " (roster count: " + team.getRosterCount() + ")");
//			for (Player player : team.getPlayers()) {
//				System.out.println("  Player: " + player.getNickname());
//			}
//		}
//		// Get Team by Name
//		System.out.println("\nGetting Team - Marx Brothers");
//		Team mb = port.getTeam("Marx Brothers");
//		List <Player> mbPlayers = mb.getPlayers();
//		for(Player player : mbPlayers) {
//			System.out.println("Name is " + player.getName() + " Nickname is " + player.getNickname());
//		}
	}
}