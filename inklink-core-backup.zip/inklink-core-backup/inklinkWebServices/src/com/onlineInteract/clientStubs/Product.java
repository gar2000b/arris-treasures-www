
package com.onlineInteract.clientStubs;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for product complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="product">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="accreditation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bcUpgrade" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="costsPrice" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="costsVat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="delivery" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dispatchedWithin24Hours" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="four_hundred_gsm_matt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="glueAndAssemble" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="image" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="laminate_s_s" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="marker" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="met_ink_s_s" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paperDimensions" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paperQuantity" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paperSidesPages" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paperSize" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paperStock" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paperWeight" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productCategory" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productOrder" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="productSubCategory" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="production" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "product", propOrder = {
    "accreditation",
    "bcUpgrade",
    "costsPrice",
    "costsVat",
    "delivery",
    "dispatchedWithin24Hours",
    "fourHundredGsmMatt",
    "glueAndAssemble",
    "image",
    "laminateSS",
    "marker",
    "metInkSS",
    "paperDimensions",
    "paperQuantity",
    "paperSidesPages",
    "paperSize",
    "paperStock",
    "paperWeight",
    "productCategory",
    "productCode",
    "productDescription",
    "productOrder",
    "productSubCategory",
    "production"
})
public class Product {

    protected String accreditation;
    protected String bcUpgrade;
    protected String costsPrice;
    protected String costsVat;
    protected String delivery;
    protected String dispatchedWithin24Hours;
    @XmlElement(name = "four_hundred_gsm_matt")
    protected String fourHundredGsmMatt;
    protected String glueAndAssemble;
    protected String image;
    @XmlElement(name = "laminate_s_s")
    protected String laminateSS;
    protected String marker;
    @XmlElement(name = "met_ink_s_s")
    protected String metInkSS;
    protected String paperDimensions;
    protected String paperQuantity;
    protected String paperSidesPages;
    protected String paperSize;
    protected String paperStock;
    protected String paperWeight;
    protected String productCategory;
    protected String productCode;
    protected String productDescription;
    protected String productOrder;
    protected String productSubCategory;
    protected String production;

    /**
     * Gets the value of the accreditation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccreditation() {
        return accreditation;
    }

    /**
     * Sets the value of the accreditation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccreditation(String value) {
        this.accreditation = value;
    }

    /**
     * Gets the value of the bcUpgrade property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBcUpgrade() {
        return bcUpgrade;
    }

    /**
     * Sets the value of the bcUpgrade property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBcUpgrade(String value) {
        this.bcUpgrade = value;
    }

    /**
     * Gets the value of the costsPrice property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCostsPrice() {
        return costsPrice;
    }

    /**
     * Sets the value of the costsPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCostsPrice(String value) {
        this.costsPrice = value;
    }

    /**
     * Gets the value of the costsVat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCostsVat() {
        return costsVat;
    }

    /**
     * Sets the value of the costsVat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCostsVat(String value) {
        this.costsVat = value;
    }

    /**
     * Gets the value of the delivery property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDelivery() {
        return delivery;
    }

    /**
     * Sets the value of the delivery property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDelivery(String value) {
        this.delivery = value;
    }

    /**
     * Gets the value of the dispatchedWithin24Hours property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDispatchedWithin24Hours() {
        return dispatchedWithin24Hours;
    }

    /**
     * Sets the value of the dispatchedWithin24Hours property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDispatchedWithin24Hours(String value) {
        this.dispatchedWithin24Hours = value;
    }

    /**
     * Gets the value of the fourHundredGsmMatt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFourHundredGsmMatt() {
        return fourHundredGsmMatt;
    }

    /**
     * Sets the value of the fourHundredGsmMatt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFourHundredGsmMatt(String value) {
        this.fourHundredGsmMatt = value;
    }

    /**
     * Gets the value of the glueAndAssemble property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGlueAndAssemble() {
        return glueAndAssemble;
    }

    /**
     * Sets the value of the glueAndAssemble property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGlueAndAssemble(String value) {
        this.glueAndAssemble = value;
    }

    /**
     * Gets the value of the image property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getImage() {
        return image;
    }

    /**
     * Sets the value of the image property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setImage(String value) {
        this.image = value;
    }

    /**
     * Gets the value of the laminateSS property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLaminateSS() {
        return laminateSS;
    }

    /**
     * Sets the value of the laminateSS property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLaminateSS(String value) {
        this.laminateSS = value;
    }

    /**
     * Gets the value of the marker property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMarker() {
        return marker;
    }

    /**
     * Sets the value of the marker property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMarker(String value) {
        this.marker = value;
    }

    /**
     * Gets the value of the metInkSS property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMetInkSS() {
        return metInkSS;
    }

    /**
     * Sets the value of the metInkSS property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMetInkSS(String value) {
        this.metInkSS = value;
    }

    /**
     * Gets the value of the paperDimensions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaperDimensions() {
        return paperDimensions;
    }

    /**
     * Sets the value of the paperDimensions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaperDimensions(String value) {
        this.paperDimensions = value;
    }

    /**
     * Gets the value of the paperQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaperQuantity() {
        return paperQuantity;
    }

    /**
     * Sets the value of the paperQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaperQuantity(String value) {
        this.paperQuantity = value;
    }

    /**
     * Gets the value of the paperSidesPages property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaperSidesPages() {
        return paperSidesPages;
    }

    /**
     * Sets the value of the paperSidesPages property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaperSidesPages(String value) {
        this.paperSidesPages = value;
    }

    /**
     * Gets the value of the paperSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaperSize() {
        return paperSize;
    }

    /**
     * Sets the value of the paperSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaperSize(String value) {
        this.paperSize = value;
    }

    /**
     * Gets the value of the paperStock property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaperStock() {
        return paperStock;
    }

    /**
     * Sets the value of the paperStock property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaperStock(String value) {
        this.paperStock = value;
    }

    /**
     * Gets the value of the paperWeight property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaperWeight() {
        return paperWeight;
    }

    /**
     * Sets the value of the paperWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaperWeight(String value) {
        this.paperWeight = value;
    }

    /**
     * Gets the value of the productCategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductCategory() {
        return productCategory;
    }

    /**
     * Sets the value of the productCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductCategory(String value) {
        this.productCategory = value;
    }

    /**
     * Gets the value of the productCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductCode() {
        return productCode;
    }

    /**
     * Sets the value of the productCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductCode(String value) {
        this.productCode = value;
    }

    /**
     * Gets the value of the productDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductDescription() {
        return productDescription;
    }

    /**
     * Sets the value of the productDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductDescription(String value) {
        this.productDescription = value;
    }

    /**
     * Gets the value of the productOrder property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductOrder() {
        return productOrder;
    }

    /**
     * Sets the value of the productOrder property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductOrder(String value) {
        this.productOrder = value;
    }

    /**
     * Gets the value of the productSubCategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductSubCategory() {
        return productSubCategory;
    }

    /**
     * Sets the value of the productSubCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductSubCategory(String value) {
        this.productSubCategory = value;
    }

    /**
     * Gets the value of the production property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProduction() {
        return production;
    }

    /**
     * Sets the value of the production property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProduction(String value) {
        this.production = value;
    }

}
