
package com.onlineInteract.clientStubs;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.onlineInteract.clientStubs package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _DeliveryAddress_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "deliveryAddress");
    private final static QName _AddProductResponse_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "addProductResponse");
    private final static QName _RemoveProduct_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "removeProduct");
    private final static QName _CreateOrderNoResponse_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "createOrderNoResponse");
    private final static QName _GetTimeAsElapsed_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "getTimeAsElapsed");
    private final static QName _AddOrderAddress_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "addOrderAddress");
    private final static QName _Product_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "product");
    private final static QName _GetCatalogueDateResponse_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "getCatalogueDateResponse");
    private final static QName _GetTimeAsStringResponse_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "getTimeAsStringResponse");
    private final static QName _UpdateProductResponse_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "updateProductResponse");
    private final static QName _UpdateCustomer_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "updateCustomer");
    private final static QName _AddOrderResponse_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "addOrderResponse");
    private final static QName _RemoveProductResponse_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "removeProductResponse");
    private final static QName _GetTimeAsString_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "getTimeAsString");
    private final static QName _UpdateUserPassword_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "updateUserPassword");
    private final static QName _AddProduct_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "addProduct");
    private final static QName _UpdateUserPasswordResponse_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "updateUserPasswordResponse");
    private final static QName _GetFirstMessageResponse_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "getFirstMessageResponse");
    private final static QName _AddCustomerResponse_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "addCustomerResponse");
    private final static QName _CreateOrderNo_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "createOrderNo");
    private final static QName _GetFirstMessage_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "getFirstMessage");
    private final static QName _AddCustomer_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "addCustomer");
    private final static QName _Credentials_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "credentials");
    private final static QName _UpdateCustomerResponse_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "updateCustomerResponse");
    private final static QName _UpdateProduct_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "updateProduct");
    private final static QName _GetCatalogue_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "getCatalogue");
    private final static QName _Customer_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "customer");
    private final static QName _GetCatalogueResponse_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "getCatalogueResponse");
    private final static QName _AddOrderAddressResponse_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "addOrderAddressResponse");
    private final static QName _GetCatalogueDate_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "getCatalogueDate");
    private final static QName _AddOrder_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "addOrder");
    private final static QName _GetTimeAsElapsedResponse_QNAME = new QName("http://interfaces.server.onlineInteract.com/", "getTimeAsElapsedResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.onlineInteract.clientStubs
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link AddProductResponse }
     * 
     */
    public AddProductResponse createAddProductResponse() {
        return new AddProductResponse();
    }

    /**
     * Create an instance of {@link Customer }
     * 
     */
    public Customer createCustomer() {
        return new Customer();
    }

    /**
     * Create an instance of {@link AddOrderAddressResponse }
     * 
     */
    public AddOrderAddressResponse createAddOrderAddressResponse() {
        return new AddOrderAddressResponse();
    }

    /**
     * Create an instance of {@link GetFirstMessageResponse }
     * 
     */
    public GetFirstMessageResponse createGetFirstMessageResponse() {
        return new GetFirstMessageResponse();
    }

    /**
     * Create an instance of {@link GetCatalogueResponse }
     * 
     */
    public GetCatalogueResponse createGetCatalogueResponse() {
        return new GetCatalogueResponse();
    }

    /**
     * Create an instance of {@link UpdateProductResponse }
     * 
     */
    public UpdateProductResponse createUpdateProductResponse() {
        return new UpdateProductResponse();
    }

    /**
     * Create an instance of {@link Credentials }
     * 
     */
    public Credentials createCredentials() {
        return new Credentials();
    }

    /**
     * Create an instance of {@link GetTimeAsElapsed }
     * 
     */
    public GetTimeAsElapsed createGetTimeAsElapsed() {
        return new GetTimeAsElapsed();
    }

    /**
     * Create an instance of {@link GetCatalogue }
     * 
     */
    public GetCatalogue createGetCatalogue() {
        return new GetCatalogue();
    }

    /**
     * Create an instance of {@link GetFirstMessage }
     * 
     */
    public GetFirstMessage createGetFirstMessage() {
        return new GetFirstMessage();
    }

    /**
     * Create an instance of {@link RemoveProduct }
     * 
     */
    public RemoveProduct createRemoveProduct() {
        return new RemoveProduct();
    }

    /**
     * Create an instance of {@link UpdateCustomerResponse }
     * 
     */
    public UpdateCustomerResponse createUpdateCustomerResponse() {
        return new UpdateCustomerResponse();
    }

    /**
     * Create an instance of {@link GetTimeAsElapsedResponse }
     * 
     */
    public GetTimeAsElapsedResponse createGetTimeAsElapsedResponse() {
        return new GetTimeAsElapsedResponse();
    }

    /**
     * Create an instance of {@link CreateOrderNoResponse }
     * 
     */
    public CreateOrderNoResponse createCreateOrderNoResponse() {
        return new CreateOrderNoResponse();
    }

    /**
     * Create an instance of {@link GetCatalogueDateResponse }
     * 
     */
    public GetCatalogueDateResponse createGetCatalogueDateResponse() {
        return new GetCatalogueDateResponse();
    }

    /**
     * Create an instance of {@link DeliveryAddress }
     * 
     */
    public DeliveryAddress createDeliveryAddress() {
        return new DeliveryAddress();
    }

    /**
     * Create an instance of {@link Product }
     * 
     */
    public Product createProduct() {
        return new Product();
    }

    /**
     * Create an instance of {@link UpdateUserPassword }
     * 
     */
    public UpdateUserPassword createUpdateUserPassword() {
        return new UpdateUserPassword();
    }

    /**
     * Create an instance of {@link RemoveProductResponse }
     * 
     */
    public RemoveProductResponse createRemoveProductResponse() {
        return new RemoveProductResponse();
    }

    /**
     * Create an instance of {@link GetTimeAsStringResponse }
     * 
     */
    public GetTimeAsStringResponse createGetTimeAsStringResponse() {
        return new GetTimeAsStringResponse();
    }

    /**
     * Create an instance of {@link AddOrderAddress }
     * 
     */
    public AddOrderAddress createAddOrderAddress() {
        return new AddOrderAddress();
    }

    /**
     * Create an instance of {@link AddOrder }
     * 
     */
    public AddOrder createAddOrder() {
        return new AddOrder();
    }

    /**
     * Create an instance of {@link UpdateUserPasswordResponse }
     * 
     */
    public UpdateUserPasswordResponse createUpdateUserPasswordResponse() {
        return new UpdateUserPasswordResponse();
    }

    /**
     * Create an instance of {@link GetCatalogueDate }
     * 
     */
    public GetCatalogueDate createGetCatalogueDate() {
        return new GetCatalogueDate();
    }

    /**
     * Create an instance of {@link UpdateProduct }
     * 
     */
    public UpdateProduct createUpdateProduct() {
        return new UpdateProduct();
    }

    /**
     * Create an instance of {@link CreateOrderNo }
     * 
     */
    public CreateOrderNo createCreateOrderNo() {
        return new CreateOrderNo();
    }

    /**
     * Create an instance of {@link AddCustomerResponse }
     * 
     */
    public AddCustomerResponse createAddCustomerResponse() {
        return new AddCustomerResponse();
    }

    /**
     * Create an instance of {@link AddCustomer }
     * 
     */
    public AddCustomer createAddCustomer() {
        return new AddCustomer();
    }

    /**
     * Create an instance of {@link AddProduct }
     * 
     */
    public AddProduct createAddProduct() {
        return new AddProduct();
    }

    /**
     * Create an instance of {@link AddOrderResponse }
     * 
     */
    public AddOrderResponse createAddOrderResponse() {
        return new AddOrderResponse();
    }

    /**
     * Create an instance of {@link UpdateCustomer }
     * 
     */
    public UpdateCustomer createUpdateCustomer() {
        return new UpdateCustomer();
    }

    /**
     * Create an instance of {@link GetTimeAsString }
     * 
     */
    public GetTimeAsString createGetTimeAsString() {
        return new GetTimeAsString();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeliveryAddress }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "deliveryAddress")
    public JAXBElement<DeliveryAddress> createDeliveryAddress(DeliveryAddress value) {
        return new JAXBElement<DeliveryAddress>(_DeliveryAddress_QNAME, DeliveryAddress.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddProductResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "addProductResponse")
    public JAXBElement<AddProductResponse> createAddProductResponse(AddProductResponse value) {
        return new JAXBElement<AddProductResponse>(_AddProductResponse_QNAME, AddProductResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveProduct }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "removeProduct")
    public JAXBElement<RemoveProduct> createRemoveProduct(RemoveProduct value) {
        return new JAXBElement<RemoveProduct>(_RemoveProduct_QNAME, RemoveProduct.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateOrderNoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "createOrderNoResponse")
    public JAXBElement<CreateOrderNoResponse> createCreateOrderNoResponse(CreateOrderNoResponse value) {
        return new JAXBElement<CreateOrderNoResponse>(_CreateOrderNoResponse_QNAME, CreateOrderNoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTimeAsElapsed }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "getTimeAsElapsed")
    public JAXBElement<GetTimeAsElapsed> createGetTimeAsElapsed(GetTimeAsElapsed value) {
        return new JAXBElement<GetTimeAsElapsed>(_GetTimeAsElapsed_QNAME, GetTimeAsElapsed.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddOrderAddress }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "addOrderAddress")
    public JAXBElement<AddOrderAddress> createAddOrderAddress(AddOrderAddress value) {
        return new JAXBElement<AddOrderAddress>(_AddOrderAddress_QNAME, AddOrderAddress.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Product }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "product")
    public JAXBElement<Product> createProduct(Product value) {
        return new JAXBElement<Product>(_Product_QNAME, Product.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCatalogueDateResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "getCatalogueDateResponse")
    public JAXBElement<GetCatalogueDateResponse> createGetCatalogueDateResponse(GetCatalogueDateResponse value) {
        return new JAXBElement<GetCatalogueDateResponse>(_GetCatalogueDateResponse_QNAME, GetCatalogueDateResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTimeAsStringResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "getTimeAsStringResponse")
    public JAXBElement<GetTimeAsStringResponse> createGetTimeAsStringResponse(GetTimeAsStringResponse value) {
        return new JAXBElement<GetTimeAsStringResponse>(_GetTimeAsStringResponse_QNAME, GetTimeAsStringResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateProductResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "updateProductResponse")
    public JAXBElement<UpdateProductResponse> createUpdateProductResponse(UpdateProductResponse value) {
        return new JAXBElement<UpdateProductResponse>(_UpdateProductResponse_QNAME, UpdateProductResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateCustomer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "updateCustomer")
    public JAXBElement<UpdateCustomer> createUpdateCustomer(UpdateCustomer value) {
        return new JAXBElement<UpdateCustomer>(_UpdateCustomer_QNAME, UpdateCustomer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddOrderResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "addOrderResponse")
    public JAXBElement<AddOrderResponse> createAddOrderResponse(AddOrderResponse value) {
        return new JAXBElement<AddOrderResponse>(_AddOrderResponse_QNAME, AddOrderResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveProductResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "removeProductResponse")
    public JAXBElement<RemoveProductResponse> createRemoveProductResponse(RemoveProductResponse value) {
        return new JAXBElement<RemoveProductResponse>(_RemoveProductResponse_QNAME, RemoveProductResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTimeAsString }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "getTimeAsString")
    public JAXBElement<GetTimeAsString> createGetTimeAsString(GetTimeAsString value) {
        return new JAXBElement<GetTimeAsString>(_GetTimeAsString_QNAME, GetTimeAsString.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateUserPassword }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "updateUserPassword")
    public JAXBElement<UpdateUserPassword> createUpdateUserPassword(UpdateUserPassword value) {
        return new JAXBElement<UpdateUserPassword>(_UpdateUserPassword_QNAME, UpdateUserPassword.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddProduct }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "addProduct")
    public JAXBElement<AddProduct> createAddProduct(AddProduct value) {
        return new JAXBElement<AddProduct>(_AddProduct_QNAME, AddProduct.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateUserPasswordResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "updateUserPasswordResponse")
    public JAXBElement<UpdateUserPasswordResponse> createUpdateUserPasswordResponse(UpdateUserPasswordResponse value) {
        return new JAXBElement<UpdateUserPasswordResponse>(_UpdateUserPasswordResponse_QNAME, UpdateUserPasswordResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFirstMessageResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "getFirstMessageResponse")
    public JAXBElement<GetFirstMessageResponse> createGetFirstMessageResponse(GetFirstMessageResponse value) {
        return new JAXBElement<GetFirstMessageResponse>(_GetFirstMessageResponse_QNAME, GetFirstMessageResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddCustomerResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "addCustomerResponse")
    public JAXBElement<AddCustomerResponse> createAddCustomerResponse(AddCustomerResponse value) {
        return new JAXBElement<AddCustomerResponse>(_AddCustomerResponse_QNAME, AddCustomerResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateOrderNo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "createOrderNo")
    public JAXBElement<CreateOrderNo> createCreateOrderNo(CreateOrderNo value) {
        return new JAXBElement<CreateOrderNo>(_CreateOrderNo_QNAME, CreateOrderNo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFirstMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "getFirstMessage")
    public JAXBElement<GetFirstMessage> createGetFirstMessage(GetFirstMessage value) {
        return new JAXBElement<GetFirstMessage>(_GetFirstMessage_QNAME, GetFirstMessage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddCustomer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "addCustomer")
    public JAXBElement<AddCustomer> createAddCustomer(AddCustomer value) {
        return new JAXBElement<AddCustomer>(_AddCustomer_QNAME, AddCustomer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Credentials }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "credentials")
    public JAXBElement<Credentials> createCredentials(Credentials value) {
        return new JAXBElement<Credentials>(_Credentials_QNAME, Credentials.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateCustomerResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "updateCustomerResponse")
    public JAXBElement<UpdateCustomerResponse> createUpdateCustomerResponse(UpdateCustomerResponse value) {
        return new JAXBElement<UpdateCustomerResponse>(_UpdateCustomerResponse_QNAME, UpdateCustomerResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateProduct }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "updateProduct")
    public JAXBElement<UpdateProduct> createUpdateProduct(UpdateProduct value) {
        return new JAXBElement<UpdateProduct>(_UpdateProduct_QNAME, UpdateProduct.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCatalogue }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "getCatalogue")
    public JAXBElement<GetCatalogue> createGetCatalogue(GetCatalogue value) {
        return new JAXBElement<GetCatalogue>(_GetCatalogue_QNAME, GetCatalogue.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Customer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "customer")
    public JAXBElement<Customer> createCustomer(Customer value) {
        return new JAXBElement<Customer>(_Customer_QNAME, Customer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCatalogueResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "getCatalogueResponse")
    public JAXBElement<GetCatalogueResponse> createGetCatalogueResponse(GetCatalogueResponse value) {
        return new JAXBElement<GetCatalogueResponse>(_GetCatalogueResponse_QNAME, GetCatalogueResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddOrderAddressResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "addOrderAddressResponse")
    public JAXBElement<AddOrderAddressResponse> createAddOrderAddressResponse(AddOrderAddressResponse value) {
        return new JAXBElement<AddOrderAddressResponse>(_AddOrderAddressResponse_QNAME, AddOrderAddressResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCatalogueDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "getCatalogueDate")
    public JAXBElement<GetCatalogueDate> createGetCatalogueDate(GetCatalogueDate value) {
        return new JAXBElement<GetCatalogueDate>(_GetCatalogueDate_QNAME, GetCatalogueDate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddOrder }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "addOrder")
    public JAXBElement<AddOrder> createAddOrder(AddOrder value) {
        return new JAXBElement<AddOrder>(_AddOrder_QNAME, AddOrder.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTimeAsElapsedResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interfaces.server.onlineInteract.com/", name = "getTimeAsElapsedResponse")
    public JAXBElement<GetTimeAsElapsedResponse> createGetTimeAsElapsedResponse(GetTimeAsElapsedResponse value) {
        return new JAXBElement<GetTimeAsElapsedResponse>(_GetTimeAsElapsedResponse_QNAME, GetTimeAsElapsedResponse.class, null, value);
    }

}
