@javax.xml.bind.annotation.XmlSchema(namespace = "http://interfaces.server.onlineInteract.com/")
package com.onlineInteract.clientStubs;
