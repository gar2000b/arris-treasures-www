package com.onlineInteract.staticMethods;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.onlineInteract.server.InkLinkServerImpl;

public class LogUtil {

	private static Logger logger;
	
	public LogUtil(){
		initialiseLogger("");
	}
	
	public LogUtil(String applicationPath) {
		initialiseLogger(applicationPath);
	}

	private static void initialiseLogger(String applicationPath) {
		// System.out.println("App Path passed in is " + applicationPath);
		PropertyConfigurator.configure(applicationPath + "log4j.properties");
		logger = Logger.getLogger(InkLinkServerImpl.class.getName());
	}
	
	public static Logger getLogger() {
		return logger;
	}
	
}
