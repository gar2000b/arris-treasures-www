package com.onlineInteract.client;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;

import com.onlineInteract.clientStubs.Credentials;
import com.onlineInteract.clientStubs.Customer;
import com.onlineInteract.clientStubs.DeliveryAddress;
import com.onlineInteract.clientStubs.InkLinkServer;
import com.onlineInteract.clientStubs.InkLinkServerImplService;
import com.onlineInteract.clientStubs.Product;

public class InkLinkClient {

	public static void main(String args[]) {
		URL url = null;
		try {
			// url = new URL("http://88.208.248.38:9875/inklinklive?wsdl");
			url = new URL("http://88.208.248.38:9876/inklinktest?wsdl");
		} catch (MalformedURLException e1) {
			e1.printStackTrace();
		}
		
		QName qName = new QName("http://server.onlineInteract.com/", "InkLinkServerImplService");
		
		InkLinkServerImplService service = new InkLinkServerImplService( url, qName );
		System.out.println( "Service name localPart is " + service.getServiceName().getLocalPart() );
		System.out.println( "Service name nameSpaceURI is " + service.getServiceName().getNamespaceURI() );
		// System.out.println( "Service name prefix is " + service.getServiceName().getPrefix() );
		InkLinkServer port = service.getInkLinkServerImplPort();
		
		Credentials credentials = new Credentials();
		
//		credentials.setUserId(2);
//		credentials.setUsername("gar2000b");
//		credentials.setPassword("technology");
		
		
		credentials.setUserId(128);
		credentials.setUsername("tictoc");
		credentials.setPassword("t2i6c3t2o5c9");
		
//		credentials.setUserId(129);
//		credentials.setUsername("inkshoponline");
//		credentials.setPassword("i4n5k8s1h9p0");
		
		Customer customer = new Customer();
		customer.setAccountNo("A1IS0002");
		customer.setCompanyName("A2");
		customer.setContactName("AB2");
		customer.setEmail("gar2001b@yahoo.com");
		customer.setCustomersBranch("Online Interact13");
		customer.setAddress1("35 Murchison Drive13");
		customer.setAddress2("Westwood13");
		customer.setTownCity("East Kilbride13");
		customer.setPostcode("G75 8HF");
		customer.setTelephone1("01355  5237801");
		customer.setTelephone2("079837152361");
		customer.setFax("070060231791");
		customer.setBranchId(6);
		customer.setDeliveryAddress1("18 Beauly Place13");
		customer.setDeliveryAddress2("West Mains13");
		customer.setDeliveryTownCity("East Kilbride13");
		customer.setDeliveryPostcode("G74 1DD");
		
//		String accountNo = port.addCustomer(credentials, customer);
//		System.out.println("Customer Account No is " + accountNo);
		String flag = port.updateCustomer(credentials, customer);
		System.out.println("Update Customer is " + flag);
		
//		String orderNo = port.createOrderNo(credentials, "THRE0009");
//		System.out.println("Order no is " + orderNo);
		
		// Construct alternate delivery address
//		DeliveryAddress deliveryAddress = new DeliveryAddress();
//		deliveryAddress.setDeliveryName("Gary Black");
//		deliveryAddress.setDeliveryAddress1("185");
//		deliveryAddress.setDeliveryAddress2("High Street");
//		deliveryAddress.setDeliveryTownCity("Glasgow");
//		deliveryAddress.setDeliveryPostcode("G73 82Z");
		
//		double totalCost = 183.00;
//		List<String> productCodes = new ArrayList<String>();
//		productCodes.add("P-0011");
//		productCodes.add("P-0174");
//		productCodes.add("ISP2884");
//		port.addOrder(credentials, "ISO29096", productCodes, totalCost);
//		port.addOrderAddress(credentials, "ISO29100", productCodes, deliveryAddress, totalCost);
		
//		String result = port.updateCustomer(credentials, customer);
//		System.out.println("Result is " + result);
//		
//		String message = port.getFirstMessage();
//		System.out.println("Message is " + message);
		
//		System.out.println("Getting Catalogue");
//		System.out.println("-----------------");
//		List<Product> products = port.getCatalogue(credentials);
//		if(products.isEmpty()) {
//			System.out.println("Products are null or empty");
//		} else {
//			int counter = 0;
//			for (Product product : products) {
//				counter++;
//				System.out.println("* " + product.getProductOrder() + " - " + product.getProductSubCategory());
//			}
//			System.out.println("\nTotal no of products is " + counter);
//		}
		
		
//		System.out.println("Getting Catalogue Date");
//		System.out.println("-----------------");
//		
//		try {
//			GregorianCalendar c = new GregorianCalendar();
//			// Set time to 24 hours ago.
//			long testTime = System.currentTimeMillis() - (86400000);
//			System.out.println("time in millis from a day ago is " + testTime);
//			c.setTime( new Date( System.currentTimeMillis() - (172800000) ) );
//			XMLGregorianCalendar cal = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
//			List<Product> products = port.getCatalogueDate(credentials, cal);
//			
//			for (Product product : products) {
//				System.out.println("Product Sub Category is " + product.getProductSubCategory());
//			}
//			
//			System.out.println("Product length is " + products.size());
//			
//		} catch (DatatypeConfigurationException e) {
//			e.printStackTrace();
//		}
		
		
//		System.out.println("Updating user password");
//		String result = port.updateUserPassword(credentials, "scotland");
//		System.out.println("Result is " + result);
		
		// Date dt = new Date();
		// Calendar calendar;
		// calendar.setTime(new Date());
		// calendar;
		// List<Product> productsDate = port.getCatalogueDate(credentials, );
	}
	
}