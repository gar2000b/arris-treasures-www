package com.onlineInteract.applications;

import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.ParameterStyle;
import javax.sql.DataSource;
import javax.xml.ws.Endpoint;

import org.apache.commons.dbcp.ConnectionFactory;
import org.apache.commons.dbcp.DriverManagerConnectionFactory;
import org.apache.commons.dbcp.PoolableConnectionFactory;
import org.apache.commons.dbcp.PoolingDataSource;
import org.apache.commons.pool.ObjectPool;
import org.apache.commons.pool.impl.GenericObjectPool;

import com.onlineInteract.server.InkLinkServerImpl;

@SOAPBinding(parameterStyle=ParameterStyle.BARE)
public class InkLinkPublisherMultiThreaded {

	private Endpoint endpoint;
	private DataSource dataSource;
	private static String url;
	private static String dbName;
	private static String driver;
	private static String userName;
	private static String dbPassword;
	private String env;
	
	// private Statement statement;
	
	// Constructor
	public InkLinkPublisherMultiThreaded( String env ) {
		this.env = env;
		// Initialise Database - connections are now being created and closed
		// whenever a web service is invoked on the fly.
		// initDB( env );
		dataSource = setupDataSource(this.env);
	}
	
	public static void main( String args[] ) {
		
		// Port no 9875 for live, 9876 for test.. args[0] = environment.
		int portNo = 9875;
		String environment = "live";
		if( args[0].equals("live") ) {
			portNo = 9875;
			environment = "live";
		}
		else if( args[0].equals("test") ) {
			portNo = 9876;
			environment = "test";
		} 
		else {
			// Must be live
			portNo = 9875;
			environment = "live";
		}
		
		InkLinkPublisherMultiThreaded self = new InkLinkPublisherMultiThreaded( environment );
    	self.create_endpoint( environment );
    	self.configure_endpoint();
    	self.publish( environment, portNo );
	}
	
    private void create_endpoint( String environment ) {
    	endpoint = Endpoint.create(new InkLinkServerImpl(environment, dataSource));
    }
    
    private void configure_endpoint() {
    	endpoint.setExecutor(new MyThreadPool());
    }
    
    private void publish( String env, int portNo ) {
    	
    	System.out.println("*** Total memory is (cp)" + Runtime.getRuntime().totalMemory());
    	System.out.println("*** Max memory is (cp)" + Runtime.getRuntime().maxMemory());
    	System.out.println("*** Free memory is (cp)" + Runtime.getRuntime().freeMemory() + "\n");
    	int port = portNo;
    	String appPath = "";
    	if ( env.equals("live") ) {
    		appPath = "/inklinklive";
    	} else if( env.equals("test") ) {
    		appPath = "/inklinktest";
    	}
    	String url = "http://0.0.0.0:" + port + appPath;
    	endpoint.publish(url);
    	System.out.println("Version 0.0.49 Publishing InkLinkServer on port " + port + " on *" + env + "* url is " + url);
    }
    
    public static DataSource setupDataSource(String env) {
    	
		System.out.println("MYSQL Connect Datasource Setup.");
		if( env.equals("live") ) {
			url = "jdbc:mysql://localhost:3306/";
			dbName = "inkshopcrm";
			driver  = "com.mysql.jdbc.Driver";
			userName = "inkshopcrm1";
			dbPassword = "Inkshopcrm1";
		}
		else if( env.equals("test") ) {	
			url = "jdbc:mysql://localhost:3306/";
			dbName = "testinkshopcrm";
			driver  = "com.mysql.jdbc.Driver";
			userName = "inkshopcrm3";
			dbPassword = "Inkshopcrm3";
		}
    	
        System.out.println("Loading underlying JDBC driver.");
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        System.out.println("Done.");
		
        //
        // First, we'll need a ObjectPool that serves as the
        // actual pool of connections.
        //
        // We'll use a GenericObjectPool instance, although
        // any ObjectPool implementation will suffice.
        //
        ObjectPool connectionPool = new GenericObjectPool(null);

        //
        // Next, we'll create a ConnectionFactory that the
        // pool will use to create Connections.
        // We'll use the DriverManagerConnectionFactory,
        // using the connect string passed in the command line
        // arguments.
        //
        // String uri = "jdbc:mysql://88.208.248.38:3306/testinkshopcrm?user=inkshopcrm3&password=Inkshopcrm3&autoReconnect=true";
        String uri = url + dbName + "?user=" + userName + "&password=" + dbPassword + "&autoReconnect=true";
        ConnectionFactory connectionFactory = new DriverManagerConnectionFactory(uri,null);

        //
        // Now we'll create the PoolableConnectionFactory, which wraps
        // the "real" Connections created by the ConnectionFactory with
        // the classes that implement the pooling functionality.
        //
        @SuppressWarnings("unused")
		PoolableConnectionFactory poolableConnectionFactory = new PoolableConnectionFactory(connectionFactory,connectionPool,null,null,false,true);

        //
        // Finally, we create the PoolingDriver itself,
        // passing in the object pool we created.
        //
        PoolingDataSource dataSource = new PoolingDataSource(connectionPool);

        return dataSource;
    }

}
