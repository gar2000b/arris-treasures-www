package com.onlineInteract.utility;

public class Utility {

	// This method escapes all three problematic sql characters: \ ' "
	public static String escapeProblematicSQLChars(String input) {
		
		if( input != null ) {
			input = input.replace("\\", "\\\\");
			input = input.replace("\"", "\\\"");
			input = input.replace("'", "\\'");
			
			return input;
		} else {
			return null;
		}
		
	}
	
}