package com.onlineInteract.dataModel;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@XmlType(propOrder = {"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""})
public class Product {

	private String productCode;
	private String productCategory;
	private String productSubCategory;
	private String productDescription;
	private String productOrder;
	private String paperQuantity;
	private String paperSize;
	private String paperDimensions;
	private String paperStock;
	private String paperWeight;
	private String paperSidesPages;
	private String costsPrice;
	private String costsVat;
	private String production;
	private String accreditation;
	private String delivery;
	private String laminate_s_s;
	private String met_ink_s_s;
	private String four_hundred_gsm_matt;
	private String glueAndAssemble;
	private String bcUpgrade;
	private String dispatchedWithin24Hours;
	private String image;
	
	private String marker;



	public String getProductCode() {
		return productCode;
	}



	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}



	public String getProductCategory() {
		return productCategory;
	}



	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}



	public String getProductSubCategory() {
		return productSubCategory;
	}



	public void setProductSubCategory(String productSubCategory) {
		this.productSubCategory = productSubCategory;
	}



	public String getProductDescription() {
		return productDescription;
	}



	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getProductOrder() {
		return productOrder;
	}

	public void setProductOrder(String productOrder) {
		this.productOrder = productOrder;
	}

	public String getPaperQuantity() {
		return paperQuantity;
	}



	public void setPaperQuantity(String paperQuantity) {
		this.paperQuantity = paperQuantity;
	}



	public String getPaperSize() {
		return paperSize;
	}



	public void setPaperSize(String paperSize) {
		this.paperSize = paperSize;
	}



	public String getPaperDimensions() {
		return paperDimensions;
	}



	public void setPaperDimensions(String paperDimensions) {
		this.paperDimensions = paperDimensions;
	}



	public String getPaperStock() {
		return paperStock;
	}



	public void setPaperStock(String paperStock) {
		this.paperStock = paperStock;
	}



	public String getPaperWeight() {
		return paperWeight;
	}



	public void setPaperWeight(String paperWeight) {
		this.paperWeight = paperWeight;
	}



	public String getPaperSidesPages() {
		return paperSidesPages;
	}



	public void setPaperSidesPages(String paperSidesPages) {
		this.paperSidesPages = paperSidesPages;
	}



	public String getCostsPrice() {
		return costsPrice;
	}



	public void setCostsPrice(String costsPrice) {
		this.costsPrice = costsPrice;
	}



	public String getCostsVat() {
		return costsVat;
	}



	public void setCostsVat(String costsVat) {
		this.costsVat = costsVat;
	}



	public String getProduction() {
		return production;
	}



	public void setProduction(String production) {
		this.production = production;
	}



	public String getAccreditation() {
		return accreditation;
	}



	public void setAccreditation(String accreditation) {
		this.accreditation = accreditation;
	}



	public String getDelivery() {
		return delivery;
	}



	public void setDelivery(String delivery) {
		this.delivery = delivery;
	}



	public String getLaminate_s_s() {
		return laminate_s_s;
	}



	public void setLaminate_s_s(String laminate_s_s) {
		this.laminate_s_s = laminate_s_s;
	}



	public String getMet_ink_s_s() {
		return met_ink_s_s;
	}



	public void setMet_ink_s_s(String met_ink_s_s) {
		this.met_ink_s_s = met_ink_s_s;
	}



	public String getFour_hundred_gsm_matt() {
		return four_hundred_gsm_matt;
	}



	public void setFour_hundred_gsm_matt(String four_hundred_gsm_matt) {
		this.four_hundred_gsm_matt = four_hundred_gsm_matt;
	}



	public String getGlueAndAssemble() {
		return glueAndAssemble;
	}



	public void setGlueAndAssemble(String glueAndAssemble) {
		this.glueAndAssemble = glueAndAssemble;
	}



	public String getBcUpgrade() {
		return bcUpgrade;
	}



	public void setBcUpgrade(String bcUpgrade) {
		this.bcUpgrade = bcUpgrade;
	}



	public String getDispatchedWithin24Hours() {
		return dispatchedWithin24Hours;
	}



	public void setDispatchedWithin24Hours(String dispatchedWithin24Hours) {
		this.dispatchedWithin24Hours = dispatchedWithin24Hours;
	}


	public String getImage() {
		return image;
	}



	public void setImage(String image) {
		this.image = image;
	}
	

	public String getMarker() {
		return marker;
	}



	public void setMarker(String marker) {
		this.marker = marker;
	}



	// Constructor.
	public Product() {}
	
}
