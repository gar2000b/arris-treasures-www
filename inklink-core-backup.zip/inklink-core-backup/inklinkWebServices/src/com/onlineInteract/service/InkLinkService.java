package com.onlineInteract.service;

import java.util.List;

import org.hibernate.SessionFactory;

import com.onlineInteract.dao.ProductDAOImpl;
import com.onlineInteract.dataModel.entities.ProductEntity;

public class InkLinkService {

	private static SessionFactory factory;
	
	public static SessionFactory getFactory() {
		return factory;
	}

	public static void setFactory(SessionFactory factory) {
		InkLinkService.factory = factory;
	}

	public static ProductEntity getProduct(Integer id) {
		return ProductDAOImpl.getProduct(id);
	}
	
	public static List<ProductEntity> getProductCatalogue(Integer catalogueId) {
		return ProductDAOImpl.getProductCatalogue(catalogueId);
	}
}
