package com.onlineInteract.server.interfaces;

import java.util.Calendar;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import com.onlineInteract.dataModel.Credentials;
import com.onlineInteract.dataModel.Customer;
import com.onlineInteract.dataModel.DeliveryAddress;
import com.onlineInteract.dataModel.Product;

@WebService
@SOAPBinding(style = Style.DOCUMENT)
public interface InkLinkServer {
    @WebMethod String getTimeAsString();
    @WebMethod long getTimeAsElapsed();
    @WebMethod String getFirstMessage();
    @WebMethod String addCustomer(Credentials credentials, Customer customer);
    @WebMethod String updateCustomer(Credentials credentials, Customer customer);
    @WebMethod String updateUserPassword(Credentials credentials, String newPassword);
    @WebMethod String addProduct(Credentials credentials, Product product);
    @WebMethod String updateProduct(Credentials credentials, Product product);
    @WebMethod String removeProduct(Credentials credentials, String productCode);
    @WebMethod List<Product> getCatalogue(Credentials credentials);
    @WebMethod List<Product> getCatalogueDate(Credentials credentials, Calendar date);
    @WebMethod String createOrderNo(Credentials credentials, String accountNo);
    @WebMethod String addOrder(Credentials credentials, String orderNo, List<String> productCodes, double totalCost);
    @WebMethod String addOrderAddress(Credentials credentials, String orderNo, List<String> productCodes, DeliveryAddress alternateDeliveryAddress, double totalCost);
}
