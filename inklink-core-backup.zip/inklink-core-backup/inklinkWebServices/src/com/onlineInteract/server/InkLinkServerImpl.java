package com.onlineInteract.server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.jws.WebService;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.onlineInteract.dataModel.Credentials;
import com.onlineInteract.dataModel.Customer;
import com.onlineInteract.dataModel.DeliveryAddress;
import com.onlineInteract.dataModel.Product;
import com.onlineInteract.server.interfaces.InkLinkServer;
import com.onlineInteract.staticMethods.LogUtil;
import com.onlineInteract.utility.Utility;

@WebService(endpointInterface = "com.onlineInteract.server.interfaces.InkLinkServer")
public class InkLinkServerImpl implements InkLinkServer {

	private Statement statement;
	private DataSource dataSource;
	private Connection connection;
	private static Logger log;
	private String environment;
	
	public InkLinkServerImpl(){}
	
	public InkLinkServerImpl(String environment, DataSource dataSource) {
		
		if( environment.equals("live") ) {
			new LogUtil();
			log = LogUtil.getLogger();
			log.info("Logging Initialised");
		} else if( environment.equals("test") ) {
			new LogUtil("test-logs/");
			log = LogUtil.getLogger();
			log.info("Logging Initialised");
		}
		
		this.dataSource = dataSource;
		this.environment = environment;
	}
	
	public String getTimeAsString() { return new Date().toString(); }
	
	public long getTimeAsElapsed() { return new Date().getTime(); }
	
	public String getFirstMessage() {
		
		log.info("\n*** getFirstMessage() invoked.\n");
		// checkDBConnection();
		Connection connection = getDBConnection();
		
		String testString = "";
		
		log.info("\nFirst Message Called\nDatabaseTest:\n");
		
		log.info("***Pre DB");
		try {
			statement = connection.createStatement();
			ResultSet rs;
			rs = statement.executeQuery("SELECT * FROM test");
			log.info("Printing Test\n");
			rs.next();
			testString = rs.getString("test");
			log.info(testString);
			log.info("");
			rs.close();
			statement.close();
		} catch (Exception e) {
			log.info("Sorry, Cannot find driver");
		}
		log.info("***Post DB");
		
		log.info("Transaction complete at " + new Date().toString() );
		
		closeDB(connection);
		
		return "Message Here - " + testString;
	}
	
	public String addCustomer(Credentials credentials, Customer customer) {
		
		log.info("\n*** addCustomer() invoked.\n");
		
		// checkDBConnection();
		Connection connection = getDBConnection();
		
		// Check credentials.
		if( !checkCredentials(credentials, connection) ) {
			log.info("\nSorry, Invalid credentials");
			closeDB(connection);
			return "fail - invalid credentials passed in";
		}
		
		// log.info(customer.getAccountNo());
		log.info(credentials.getUserId());
		log.info(credentials.getUsername());
		log.info(credentials.getPassword());
		log.info(customer.getCompanyName());
		log.info(customer.getAddress1());
		log.info(customer.getAddress2());
		log.info(customer.getTownCity());
		log.info(customer.getPostcode());
		log.info(customer.getTelephone1());
		log.info(customer.getTelephone2());
		log.info(customer.getFax());
		log.info(customer.getEmail());
		log.info(customer.getCustomersBranch());
		log.info(customer.getBranchId());
		log.info(customer.getContactName());
		log.info(customer.getDeliveryAddress1());
		log.info(customer.getDeliveryAddress2());
		log.info(customer.getDeliveryTownCity());
		log.info(customer.getDeliveryPostcode());
		
		// Escape problematic chars...
		customer.setCompanyName(Utility.escapeProblematicSQLChars(customer.getCompanyName()));
		customer.setContactName(Utility.escapeProblematicSQLChars(customer.getContactName()));
		customer.setAddress1(Utility.escapeProblematicSQLChars(customer.getAddress1()));
		customer.setAddress2(Utility.escapeProblematicSQLChars(customer.getAddress2()));
		customer.setTownCity(Utility.escapeProblematicSQLChars(customer.getTownCity()));
		customer.setDeliveryAddress1(Utility.escapeProblematicSQLChars(customer.getDeliveryAddress1()));
		customer.setDeliveryAddress2(Utility.escapeProblematicSQLChars(customer.getDeliveryAddress2()));
		customer.setDeliveryTownCity(Utility.escapeProblematicSQLChars(customer.getDeliveryTownCity()));
		
		// First thing to do is get branch_id of user.
		String branchId = "";
		try {
			statement = connection.createStatement();
			ResultSet rs;
			rs = statement.executeQuery("SELECT branch_hr.branch_id AS branch_id FROM hr_table, branch_hr WHERE hr_table.employee_number = branch_hr.employee_number AND hr_table.employee_number = '" + credentials.getUserId() + "'");
			rs.next();
			branchId = rs.getString("branch_id");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		// Check and add new customer (based on email and company name)
		// if they already exist, then update customer record with
		// all details.  If they don't exist, then add new customer.
		// Get user record from database based on userId.
		try {
			statement = connection.createStatement();
			ResultSet rs;
			rs = statement.executeQuery("SELECT Id, account_no FROM customer WHERE email = '" + customer.getEmail() + "' AND company_name = '" + customer.getCompanyName() + "'");
			if(rs.next()){
				// If exists - update customer.
				String customerId = rs.getString("Id");
				String accountNo = rs.getString("account_no");
				log.info("Customer Exists - Update Customer");
				try {
					statement = connection.createStatement();
					int noOfUpdateResults = statement.executeUpdate("UPDATE customer SET company_name = '" + customer.getCompanyName() + "', contact_name = '" + customer.getContactName() + "', email = '" + customer.getEmail() + "', branch = '" + customer.getCustomersBranch() + "', address_1 = '" + customer.getAddress1() + "', address_2 = '" + customer.getAddress2() + "', town_city = '" + customer.getTownCity() + "', postcode = '" + customer.getPostcode() + "', telephone_1 = '" + customer.getTelephone1() + "', telephone_2 = '" + customer.getTelephone2() + "', fax = '" + customer.getFax() + "', branch_id = " + branchId + ", delivery_address_1 = '" + customer.getDeliveryAddress1() + "', delivery_address_2 = '" + customer.getDeliveryAddress2() + "', delivery_town_city = '" + customer.getDeliveryTownCity() + "', delivery_postcode = '" + customer.getDeliveryPostcode() + "', employee_no = " + credentials.getUserId() + ", updated = NOW(), account_active = 1 WHERE Id = " + customerId, Statement.RETURN_GENERATED_KEYS);
					if(noOfUpdateResults > 0) {
						log.info("Customer " + customer.getContactName() + " at " + customer.getCompanyName() + " updated successfully for " + credentials.getUsername());
						log.info("Transaction complete at " + new Date().toString() );
						closeDB(connection);
						return accountNo;
					} else {
						log.info("fail - sorry, there was a problem updating the customer.");
						log.info("Transaction complete at " + new Date().toString() );
						closeDB(connection);
						return "fail - sorry, there was a problem updating the customer.";
					}
					
				} catch (SQLException e) {
					log.info("Exception is: " + e.toString());
					log.info("Transaction complete at " + new Date().toString() );
					closeDB(connection);
					return "fail - sorry, there was a problem updating the customer.";
				}
			} else {
				// else - add new customer.
				// First generate account_no for new customer.
				log.info("Customer Doesn't Exist - Add new Customer");
				
				String companyName = customer.getCompanyName();
				String contactName = customer.getContactName();

				String accountNo = "";
				
				// If company name has a value, then gen account no
				// based on company name else gen account no based
				// on contact name.
				if( companyName != null && !companyName.equals("") ) {
					String companyNameTemp = companyName + "ISIS";
					accountNo = companyNameTemp.substring(0, 4);
				} else if( contactName != null && !contactName.equals("") ) {
					String contactNameTemp = contactName + "ISIS";
					accountNo = contactNameTemp.substring(0, 4);
				} else {
					accountNo = "CUST";
				}
				String accountNoFirstPart = accountNo;
				accountNoFirstPart = accountNoFirstPart.toUpperCase();
				
				// If Company Name and Contact Name are both Empty, then
				// set them both to - (details required - tic toc)
				if( (companyName == null || companyName.equals("")) && (contactName == null || contactName.equals("")) ) {
					companyName = "(details required - tic toc)";
					contactName = "(details required - tic toc)";
				} else if ( companyName == null || companyName.equals("") ) {
					// If Company Name passed in is empty, then assign Company Name to
					// Contact Name and pass that into DB.
					companyName = contactName;
				}
				
				statement = connection.createStatement();
				rs = statement.executeQuery("SELECT MAX(account_no) AS account_no FROM customer WHERE account_no LIKE '" + accountNo + "%'");
				if(rs.next()){
					accountNo = rs.getString("account_no");
					log.info("0. Account No is " + accountNo);
					if(accountNo == null) {
						log.info("* Account no is indeed null.");
						accountNo = accountNoFirstPart + "0001";
					} else {
						// Now strip out char / numeric parts, increment numeric part by 1 and re-attach.
						String chars = accountNo.substring(0, 4);
						String numeric = accountNo.substring(4, 8);
						log.info("chars part is " + chars);
						log.info("numeric part is " + numeric);
						int number = Integer.parseInt(numeric);
						number++;
						numeric = String.valueOf(number);
						int lengthAdjustmentNumeric = 4 - numeric.length();
						for(int i = 0; i< lengthAdjustmentNumeric; i++) {
							numeric = "0" + numeric;
						}
						accountNo = chars + numeric;
						log.info("Number is now " + number);
						log.info("Numeric is now " + numeric);
						log.info("1. Account No is " + accountNo);
					}
				} else {
					accountNo = accountNoFirstPart + "0001";
					log.info("2. Account No is " + accountNo);
				}
				log.info("We now have the complete new account number - " + accountNo);
				
				// Now we have the new account number, we now add the new customer to the database.
				statement = connection.createStatement();
				log.info("INSERT INTO customer(account_no, company_name, contact_name, email, branch, address_1, address_2, town_city, postcode, telephone_1, telephone_2, fax, branch_id, delivery_address_1, delivery_address_2, delivery_town_city, delivery_postcode, employee_no, updated, account_active) VALUES('" + accountNo + "', '" + companyName + "', '" + contactName + "', '" + customer.getEmail() + "', '" + customer.getCustomersBranch() + "', '" + customer.getAddress1() + "', '" + customer.getAddress2() + "', '" + customer.getTownCity() + "', '" + customer.getPostcode() + "', '" + customer.getTelephone1() + "', '" + customer.getTelephone2() + "', '" + customer.getFax() + "', " + branchId + ", '" + customer.getDeliveryAddress1() + "', '" + customer.getDeliveryAddress2() + "', '" + customer.getDeliveryTownCity() + "', '" + customer.getDeliveryPostcode() + "', " + credentials.getUserId() + ", NOW(), 1)");
				int noOfUpdateResults = statement.executeUpdate("INSERT INTO customer(account_no, company_name, contact_name, email, branch, address_1, address_2, town_city, postcode, telephone_1, telephone_2, fax, branch_id, delivery_address_1, delivery_address_2, delivery_town_city, delivery_postcode, employee_no, updated, account_active) VALUES('" + accountNo + "', '" + companyName + "', '" + contactName + "', '" + customer.getEmail() + "', '" + customer.getCustomersBranch() + "', '" + customer.getAddress1() + "', '" + customer.getAddress2() + "', '" + customer.getTownCity() + "', '" + customer.getPostcode() + "', '" + customer.getTelephone1() + "', '" + customer.getTelephone2() + "', '" + customer.getFax() + "', " + branchId + ", '" + customer.getDeliveryAddress1() + "', '" + customer.getDeliveryAddress2() + "', '" + customer.getDeliveryTownCity() + "', '" + customer.getDeliveryPostcode() + "', " + credentials.getUserId() + ", NOW(), 1)", Statement.RETURN_GENERATED_KEYS);
				if(noOfUpdateResults > 0) {
					log.info("Customer " + customer.getContactName() + " at " + customer.getCompanyName() + " added successfully for " + credentials.getUsername());
					log.info("Transaction complete at " + new Date().toString() );
					closeDB(connection);
					return accountNo;
				} else {
					log.info("fail - sorry, there was a problem adding the customer.");
					log.info("Transaction complete at " + new Date().toString() );
					closeDB(connection);
					return "fail - sorry, there was a problem updating the customer.";
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		log.info("Transaction complete at " + new Date().toString() );
		
		closeDB(connection);
		
		return "ONLN0001";
	}
	
	public String updateCustomer(Credentials credentials, Customer customer) {
		
		log.info("\n*** updateCustomer() invoked.\n");
		// checkDBConnection();
		Connection connection = getDBConnection();
		
		// Check credentials.
		if( !checkCredentials(credentials, connection) ) {
			log.info("\nSorry, Invalid credentials");
			closeDB(connection);
			return "fail - invalid credentials passed in";
		}
		
		log.info("\n*** updateCustomer() invoked.\n");
		log.info(credentials.getUserId());
		log.info(credentials.getUsername());
		log.info(credentials.getPassword());
		log.info(customer.getAccountNo());
		log.info(customer.getCompanyName());
		log.info(customer.getAddress1());
		log.info(customer.getAddress2());
		log.info(customer.getTownCity());
		log.info(customer.getPostcode());
		log.info(customer.getTelephone1());
		log.info(customer.getTelephone2());
		log.info(customer.getFax());
		log.info(customer.getEmail());
		log.info(customer.getCustomersBranch());
		log.info(customer.getBranchId());
		log.info(customer.getContactName());
		log.info(customer.getDeliveryAddress1());
		log.info(customer.getDeliveryAddress2());
		log.info(customer.getDeliveryTownCity());
		log.info(customer.getDeliveryPostcode());
		
		// Escape problematic chars...
		customer.setCompanyName(Utility.escapeProblematicSQLChars(customer.getCompanyName()));
		customer.setContactName(Utility.escapeProblematicSQLChars(customer.getContactName()));
		customer.setCustomersBranch(Utility.escapeProblematicSQLChars(customer.getCustomersBranch()));
		customer.setAddress1(Utility.escapeProblematicSQLChars(customer.getAddress1()));
		customer.setAddress2(Utility.escapeProblematicSQLChars(customer.getAddress2()));
		customer.setTownCity(Utility.escapeProblematicSQLChars(customer.getTownCity()));
		customer.setDeliveryAddress1(Utility.escapeProblematicSQLChars(customer.getDeliveryAddress1()));
		customer.setDeliveryAddress2(Utility.escapeProblematicSQLChars(customer.getDeliveryAddress2()));
		customer.setDeliveryTownCity(Utility.escapeProblematicSQLChars(customer.getDeliveryTownCity()));
		
		// First thing to do is get branch_id of user.
		String branchId = "";
		try {
			statement = connection.createStatement();
			ResultSet rs;
			rs = statement.executeQuery("SELECT branch_hr.branch_id AS branch_id FROM hr_table, branch_hr WHERE hr_table.employee_number = branch_hr.employee_number AND hr_table.employee_number = '" + credentials.getUserId() + "'");
			rs.next();
			branchId = rs.getString("branch_id");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		String companyName = customer.getCompanyName();
		String contactName = customer.getContactName();
		String accountNo = "";
		String existingAccountNo = customer.getAccountNo();
		String existingChars = existingAccountNo.substring(0, 4);
		
		// If Company Name and Contact Name are both Empty, then
		// set them both to - (details required - tic toc)
		if( (companyName == null || companyName.equals("")) && (contactName == null || contactName.equals("")) ) {
			companyName = "(details required - tic toc)";
			contactName = "(details required - tic toc)";
			existingChars = "IGNORE";
		} else if ( companyName == null || companyName.equals("") ) {
			// If Company Name passed in is empty, then assign Company Name to
			// Contact Name and pass that into DB.
			companyName = contactName;
		}
		
		// Set existingChars to IGNORE if company or contact name hasn't been updated and is set to (details required - tic toc).
		if( (customer.getCompanyName() != null && customer.getCompanyName().equals("(details required - tic toc)")) && (customer.getContactName() != null && customer.getContactName().equals("(details required - tic toc)")) ) {
			log.info("Setting to IGNORE update cust account no as Tic Toc hasn't updated the company and contact names.");
			existingChars = "IGNORE";
		}
		
		// Check if companyName need characters added.
		
		// Work out new account no if required.
		
		// If existingChars is equal to CUST, then proceed with setting an account no to update.
		if( existingChars.equals("CUST") ) {
			// Work out no customer account no.
			// If company name has a value, then gen account no
			// based on company name else gen account no based
			// on contact name.
			if( companyName != null && !companyName.equals("") ) {
				String companyNameTemp = companyName + "ISIS";
				accountNo = companyNameTemp.substring(0, 4);
			} else if( contactName != null && !contactName.equals("") ) {
				String contactNameTemp = contactName + "ISIS";
				accountNo = contactNameTemp.substring(0, 4);
			} else {
				accountNo = "CUST";
			}
			String accountNoFirstPart = accountNo;
			accountNoFirstPart = accountNoFirstPart.toUpperCase();
			
			// If Company Name and Contact Name are both Empty, then
			// set them both to - (details required - tic toc)
//			if( (companyName == null || companyName.equals("")) && (contactName == null || contactName.equals("")) ) {
//				companyName = "(details required - tic toc)";
//				contactName = "(details required - tic toc)";
//			} else if ( companyName == null || companyName.equals("") ) {
//				// If Company Name passed in is empty, then assign Company Name to
//				// Contact Name and pass that into DB.
//				companyName = contactName;
//			}
			
			try {
				statement = connection.createStatement();
				ResultSet rs;
				rs = statement.executeQuery("SELECT MAX(account_no) AS account_no FROM customer WHERE account_no LIKE '" + accountNo + "%'");
				if(rs.next()){
					accountNo = rs.getString("account_no");
					log.info("0. Account No is " + accountNo);
					if(accountNo == null) {
						log.info("* Account no is indeed null.");
						accountNo = accountNoFirstPart + "0001";
					} else {
						// Now strip out char / numeric parts, increment numeric part by 1 and re-attach.
						String chars = accountNo.substring(0, 4);
						String numeric = accountNo.substring(4, 8);
						log.info("chars part is " + chars);
						log.info("numeric part is " + numeric);
						int number = Integer.parseInt(numeric);
						number++;
						numeric = String.valueOf(number);
						int lengthAdjustmentNumeric = 4 - numeric.length();
						for(int i = 0; i< lengthAdjustmentNumeric; i++) {
							numeric = "0" + numeric;
						}
						accountNo = chars + numeric;
						log.info("Number is now " + number);
						log.info("Numeric is now " + numeric);
						log.info("1. Account No is " + accountNo);
					}
				} else {
					accountNo = accountNoFirstPart + "0001";
					log.info("2. Account No is " + accountNo);
				}
				log.info("We now have the complete new account number - " + accountNo);
				
			} catch(SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		// Now get customer id based on account no.
		try {
			statement = connection.createStatement();
			ResultSet rs;
			rs = statement.executeQuery("SELECT Id FROM customer WHERE account_no = '" + customer.getAccountNo() + "'");
			if(rs.next()){
				String customerId = rs.getString("Id");
				
				// Now update
				log.info("Customer Exists - Update Customer");
				try {
					statement = connection.createStatement();
					int noOfUpdateResults = 0;
					String accountNoToReturn = "";
					// If existingChars = CUST and accountNo is longer than 0 chars, then proceed with updating customer + new account no.
					if( existingChars.equals("CUST") && accountNo.length() > 0 ) {
						noOfUpdateResults = statement.executeUpdate("UPDATE customer SET company_name = '" + companyName + "', contact_name = '" + contactName + "', email = '" + customer.getEmail() + "', branch = '" + customer.getCustomersBranch() + "', address_1 = '" + customer.getAddress1() + "', address_2 = '" + customer.getAddress2() + "', town_city = '" + customer.getTownCity() + "', postcode = '" + customer.getPostcode() + "', telephone_1 = '" + customer.getTelephone1() + "', telephone_2 = '" + customer.getTelephone2() + "', fax = '" + customer.getFax() + "', branch_id = " + branchId + ", delivery_address_1 = '" + customer.getDeliveryAddress1() + "', delivery_address_2 = '" + customer.getDeliveryAddress2() + "', delivery_town_city = '" + customer.getDeliveryTownCity() + "', delivery_postcode = '" + customer.getDeliveryPostcode() + "', employee_no = " + credentials.getUserId() + ", updated = NOW(), account_active = 1, account_no = '" + accountNo + "' WHERE Id = " + customerId, Statement.RETURN_GENERATED_KEYS);
						accountNoToReturn = accountNo;
					} else {
						noOfUpdateResults = statement.executeUpdate("UPDATE customer SET company_name = '" + companyName + "', contact_name = '" + contactName + "', email = '" + customer.getEmail() + "', branch = '" + customer.getCustomersBranch() + "', address_1 = '" + customer.getAddress1() + "', address_2 = '" + customer.getAddress2() + "', town_city = '" + customer.getTownCity() + "', postcode = '" + customer.getPostcode() + "', telephone_1 = '" + customer.getTelephone1() + "', telephone_2 = '" + customer.getTelephone2() + "', fax = '" + customer.getFax() + "', branch_id = " + branchId + ", delivery_address_1 = '" + customer.getDeliveryAddress1() + "', delivery_address_2 = '" + customer.getDeliveryAddress2() + "', delivery_town_city = '" + customer.getDeliveryTownCity() + "', delivery_postcode = '" + customer.getDeliveryPostcode() + "', employee_no = " + credentials.getUserId() + ", updated = NOW(), account_active = 1 WHERE Id = " + customerId, Statement.RETURN_GENERATED_KEYS);
						accountNoToReturn = customer.getAccountNo();
					}
					if(noOfUpdateResults > 0) {
						log.info("Customer " + customer.getContactName() + " at " + customer.getCompanyName() + " updated successfully for " + credentials.getUsername());
						log.info("Transaction complete at " + new Date().toString() );
						closeDB(connection);
						return accountNoToReturn;
					} else {
						log.info("fail - sorry, there was a problem updating the customer.");
						log.info("Transaction complete at " + new Date().toString() );
						closeDB(connection);
						return "fail - sorry, there was a problem updating the customer.";
					}
					
				} catch (SQLException e) {
					log.info("Exception is: " + e.toString());
					log.info("Transaction complete at " + new Date().toString() );
					closeDB(connection);
					return "fail - sorry, there was a problem updating the customer.";
				}
				
			} else {
				log.info("fail - sorry, invalid customer to update");
				closeDB(connection);
				return "fail - sorry, invalid customer to update";
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		log.info("Transaction complete at " + new Date().toString() );
		
		closeDB(connection);
		
		return "fail - sorry, there was a problem updating the customer.";
	}

	public String updateUserPassword(Credentials credentials, String newPassword) {
		
		log.info("\n*** updateUserPassword() invoked.\n");
		
		// checkDBConnection();
		Connection connection = getDBConnection();
		
		// Check credentials.
		if( !checkCredentials(credentials, connection) ) {
			log.info("fail - invalid credentials passed in");
			closeDB(connection);
			return "fail - invalid credentials passed in";
		}
		
		log.info(credentials.getUserId());
		log.info(credentials.getUsername());
		log.info(credentials.getPassword());
		log.info("New password is " + newPassword);
		
		int noOfUpdateResults = -1;
		// Update user password.
		try {
			statement = connection.createStatement();
			noOfUpdateResults = statement.executeUpdate("UPDATE hr_table SET member_password = SHA('" + newPassword + "') WHERE employee_number = " + credentials.getUserId(), Statement.RETURN_GENERATED_KEYS);
			if(noOfUpdateResults > 0) {
				log.info("Password updated successfully for " + credentials.getUsername());
				log.info("Transaction complete at " + new Date().toString() );
				closeDB(connection);
				return "success";
			} else {
				log.info("Transaction complete at " + new Date().toString() );
				closeDB(connection);
				return "fail - sorry, there was a problem updating your password.";
			}
			
		} catch (SQLException e) {
			log.info("Exception is: " + e.toString());
			log.info("Transaction complete at " + new Date().toString() );
			closeDB(connection);
			return "fail - sorry, there was a problem updating your password.";
		}
	}

	public String addProduct(Credentials credentials, Product product) {
		
		log.info("\n*** addProduct() invoked.\n");
		// checkDBConnection();
		Connection connection = getDBConnection();
		
		// Check credentials.
		if( !checkCredentials(credentials, connection) ) {
			log.info("\nSorry, Invalid credentials");
			return "fail - invalid credentials passed in";
		}
		
		log.info(credentials.getUserId());
		log.info(credentials.getUsername());
		log.info(credentials.getPassword());
		log.info(product.getProductCode());
		log.info(product.getProductCategory());
		log.info(product.getProductSubCategory());
		log.info(product.getProductDescription());
		log.info(product.getPaperQuantity());
		log.info(product.getPaperSize());
		log.info(product.getPaperDimensions());
		log.info(product.getPaperStock());
		log.info(product.getPaperWeight());
		log.info(product.getPaperSidesPages());
		log.info(product.getCostsVat());
		log.info(product.getCostsPrice());
		
		log.info("Transaction complete at " + new Date().toString() );
		
		closeDB(connection);
		
		return "success";
	}

	public String updateProduct(Credentials credentials, Product product) {
		
		log.info("\n*** updateProduct() invoked.\n");
		// checkDBConnection();
		Connection connection = getDBConnection();
		
		// Check credentials.
		if( !checkCredentials(credentials, connection) ) {
			log.info("\nSorry, Invalid credentials");
			return "fail - invalid credentials passed in";
		}
		
		log.info(credentials.getUserId());
		log.info(credentials.getUsername());
		log.info(credentials.getPassword());
		log.info(product.getProductCode());
		log.info(product.getProductCategory());
		log.info(product.getProductSubCategory());
		log.info(product.getProductDescription());
		log.info(product.getPaperQuantity());
		log.info(product.getPaperSize());
		log.info(product.getPaperDimensions());
		log.info(product.getPaperStock());
		log.info(product.getPaperWeight());
		log.info(product.getPaperSidesPages());
		log.info(product.getCostsVat());
		log.info(product.getCostsPrice());
		
		log.info("Transaction complete at " + new Date().toString() );
		
		closeDB(connection);
		
		return "success";
	}
	
	public String removeProduct(Credentials credentials, String productCode) {
		
		log.info("\n*** removeProduct() invoked.\n");
		// checkDBConnection();
		Connection connection = getDBConnection();
		
		// Check credentials.
		if( !checkCredentials(credentials, connection) ) {
			log.info("\nSorry, Invalid credentials");
			return "fail - invalid credentials passed in";
		}
		
		log.info(credentials.getUserId());
		log.info(credentials.getUsername());
		log.info(credentials.getPassword());
		log.info("Product Code is " + productCode);
		
		log.info("Transaction complete at " + new Date().toString() );
		
		closeDB(connection);
		
		return "success";
	}

	public String createOrderNo(Credentials credentials, String accountNo) {
		
		log.info("\n*** createOrderNo() invoked.\n");
		// checkDBConnection();
		Connection connection = getDBConnection();
		
		// Check credentials.
		if( !checkCredentials(credentials, connection) ) {
			log.info("\nSorry, Invalid credentials");
			closeDB(connection);
			return "fail - invalid credentials passed in";
		}
		
		// First thing to do is get branch_id of user.
		String branchId = "";
		try {
			statement = connection.createStatement();
			ResultSet rs;
			rs = statement.executeQuery("SELECT branch_hr.branch_id AS branch_id FROM hr_table, branch_hr WHERE hr_table.employee_number = branch_hr.employee_number AND hr_table.employee_number = '" + credentials.getUserId() + "'");
			rs.next();
			branchId = rs.getString("branch_id");
		} catch (SQLException e) {
			e.printStackTrace();
			closeDB(connection);
			return "fail - sorry, could not retrieve branch id based on userId passed in";
		}
		
		// Now get branch code based on branch id.
		String branchCode = "";
		String branchNo = "";
		try {
			statement = connection.createStatement();
			ResultSet rs;
			rs = statement.executeQuery("SELECT branch_code, branch_no FROM branch WHERE Id = " + branchId);
			rs.next();
			branchCode = rs.getString("branch_code");
			branchNo = rs.getString("branch_no");
		} catch (SQLException e) {
			e.printStackTrace();
			closeDB(connection);
			return "fail - sorry, could not retrieve branch id based on userId passed in";
		}
		
		log.info("\n*** createOrderNo() invoked.\n");
		log.info(credentials.getUserId());
		log.info(credentials.getUsername());
		log.info(credentials.getPassword());
		log.info(accountNo);
		
		int number = 0;
		
		// Construct new order no.
		try {
			statement = connection.createStatement();
			ResultSet rs;
			statement.executeUpdate("BEGIN WORK", Statement.RETURN_GENERATED_KEYS);
			rs = statement.executeQuery("SELECT order_alias_numeric.numeric AS number FROM order_alias_numeric WHERE Id = '1' FOR UPDATE");
			if(rs.next()) {
				// Extract number and increment by 1.
				number = rs.getInt("number");
				log.info("number is " + number);
				// If no is equal to 99999, then reset to 1.
				if(number == 99999) {
					number = 1;
				}
				number++;
				log.info("incremented number is " + number);
				String numberString = String.valueOf(number);
				int numberAdjustment = 5 - numberString.length();
				for(int i = 0; i < numberAdjustment; i++) {
					numberString = "0" + numberString;
				}
				// Update order_alias_numeric with newly incremented number.
				statement.executeUpdate("UPDATE order_alias_numeric SET order_alias_numeric.numeric = '" + numberString + "' WHERE Id = '1'", Statement.RETURN_GENERATED_KEYS);
				
				statement.executeUpdate("COMMIT", Statement.RETURN_GENERATED_KEYS);
				
				// Now create new order no by combining branch code with number string.
				numberString = branchCode + numberString;
				log.info("Order no is now " + numberString);
				
				// Create old order no
				Calendar currentDate = Calendar.getInstance();
				// Build up sql date_time_stamp
				int year = currentDate.get(Calendar.YEAR);
				int month = currentDate.get(Calendar.MONTH) + 1;
				int day = currentDate.get(Calendar.DAY_OF_MONTH);
				
				log.info("year: " + year);
				log.info("month: " + month);
				log.info("day: " + day);
				
				String yearString = String.valueOf(year);
				String monthString = String.valueOf(month);
				String dayString = String.valueOf(day);
				
				// Convert day and month to two digit string values.
				if(monthString.length() < 2) {
					monthString = "0" + monthString;
				}
				if(dayString.length() < 2) {
					dayString = "0" + dayString;
				}
				
				// Crop year to last two digits.
				if(yearString.length() == 4) {
					yearString = yearString.substring(2, 4);
				}
				
				log.info("yearString: " + yearString);
				log.info("monthString: " + monthString);
				log.info("dayString: " + dayString);
				
				String oldOrderNo = branchNo + "-" + dayString + "-" + monthString + "-" + yearString;
				log.info("oldOrderNo is " + oldOrderNo);
				
				// Get highest portion of old order no (from today if exists) and increment by 1. else set to 001.
				// ^ a typical order no looks like: SCSNL001-14-06-11-002 - talking about the last section
				// 002 - stripping this out and incrementing by 1 gives 003.
				
				rs = statement.executeQuery("SELECT order_no FROM orders WHERE order_no like '" + oldOrderNo + "%' ORDER BY order_no DESC LIMIT 1");
				if(rs.next()) {
					String latestOrderNo = rs.getString("order_no");
					log.info("latestOrderNo " + latestOrderNo);
					if(!latestOrderNo.equals("")) {
						// Strip out the last three chars from latest order no.
						latestOrderNo = latestOrderNo.substring(latestOrderNo.length() - 3, latestOrderNo.length());
						log.info("latestOrderNo is " + latestOrderNo);
						int latestOrderNoInt = Integer.valueOf(latestOrderNo);
						latestOrderNoInt++;
						latestOrderNo = String.valueOf(latestOrderNoInt);
						int latestOrderNoAdjustment = 3 - latestOrderNo.length();
						for(int i = 0; i < latestOrderNoAdjustment; i++) {
							latestOrderNo = "0" + latestOrderNo;
						}
					} else {
						latestOrderNo = "001";
					}
					oldOrderNo = oldOrderNo + "-" + latestOrderNo;
				} else {
					oldOrderNo = oldOrderNo + "-" + "001";
				}
				
				// SCSCG002-28-06-11-002 - from db
				// SCSCG002-28-06-11-003 - from console
				// Comparison between the two check out OK.
				
				log.info("Newly created Old order no is " + oldOrderNo);
				
				int customerId;
				String orderDate = String.valueOf(year) + "-" + monthString + "-" + dayString;
				String contactName;
				// Get customer details.
				rs = statement.executeQuery("SELECT Id, contact_name FROM customer WHERE account_no = '" + accountNo + "'");
				if(rs.next()) {
					customerId = rs.getInt("Id");
					contactName = rs.getString("contact_name");
				} else {
					closeDB(connection);
					return "fail - could not find customer based on account no supplied";
				}
				
				String usersName;
				// Get users details
				rs = statement.executeQuery("SELECT first_name, surname FROM hr_table WHERE employee_number = '" + credentials.getUserId() + "'");
				if(rs.next()) {
					String firstName = rs.getString("first_name");
					String surname = rs.getString("surname");
					usersName = firstName + " " + surname;
				} else {
					closeDB(connection);
					return "fail - could not find user based on credentials supplied";
				}
				
				log.info("Customer contact name is " + contactName);
				
				// Create a new empty order with new order no.
				int orderId = statement.executeUpdate("INSERT INTO orders(customer_id, order_no, order_date, contact_name, inkshop_contact, branch, proof_date, proof_method, delivery_date, guarantee, guarantee_date, delivery_address) VALUES(" + customerId + ", '" + oldOrderNo + "', '" + orderDate + "', '" + contactName + "', '" + usersName + "', " + branchId + ", '" + orderDate + "', 'Email', '" + orderDate + "', 'No', '" + orderDate + "', 1)", Statement.RETURN_GENERATED_KEYS);
				if(orderId > 0) {
					rs = statement.getGeneratedKeys();
					rs.next();
					orderId = rs.getInt(1);
					log.info("Id = " + orderId + " - New order created and prepared based on " + oldOrderNo);
				} else {
					closeDB(connection);
					return "fail - there was a problem inserting and preparing new order";
				}
				
				// Finally, create new order alias based on new order no.
				String orderNo = numberString;
				int orderAliasId = statement.executeUpdate("INSERT INTO order_alias(order_id, alias) VALUES(" + orderId + ", '" + orderNo + "')", Statement.RETURN_GENERATED_KEYS);
				if(orderAliasId > 0) {
					rs = statement.getGeneratedKeys();
					rs.next();
					orderAliasId = rs.getInt(1);
					log.info("Id = " + orderAliasId + " - New order created and prepared based on " + orderNo);
				} else {
					closeDB(connection);
					return "fail - there was a problem inserting and preparing new order";
				}
				
				log.info("Transaction complete at " + new Date().toString() );
				closeDB(connection);
				return orderNo;
			} else {
				statement.executeUpdate("ROLLBACK", Statement.RETURN_GENERATED_KEYS);
				log.info("Transaction complete at " + new Date().toString() );
				closeDB(connection);
				return "fail - couldn't retrieve current order no from database.";
			}
		} catch(SQLException e) {
			e.printStackTrace();
			closeDB(connection);
			return "fail - SQLException.";
		}
	}
	
	public String addOrder(Credentials credentials, String orderNo, List<String> productCodes, double totalCost) {
		
		log.info("\n*** addOrder() invoked.\n");
		// checkDBConnection();
		Connection connection = getDBConnection();
		
		// Check credentials.
		if( !checkCredentials(credentials, connection) ) {
			log.info("\nSorry, Invalid credentials");
			closeDB(connection);
			return "fail - invalid credentials passed in";
		}
		
		log.info(credentials.getUserId());
		log.info(credentials.getUsername());
		log.info(credentials.getPassword());
		log.info("Order No is " + orderNo);
		log.info("Total Cost in is: " + totalCost);
		
		String main_order_no = "";
		String main_order_id = "";
		
		// Get main order no from order alias.
		try {
			statement = connection.createStatement();
			ResultSet rs;
			rs = statement.executeQuery("SELECT order_no, orders.Id FROM orders, order_alias WHERE orders.Id = order_alias.order_id AND order_alias.alias = '" + orderNo + "'");
			rs.next();
			main_order_no = rs.getString("order_no");
			main_order_id = rs.getString("Id");
		} catch (SQLException e) {
			log.info(e.toString());
			e.printStackTrace();
			closeDB(connection);
			return "fail - sorry, could not retrieve main order no";
		}
		
		int orderItemPosition = 1;
		
		// For each product, extract all info required before insert based on productCode.
		for (String productCode : productCodes) {
			log.info("*** Product code in is - " + productCode);
			
			// Use select
			try {
				statement = connection.createStatement();
				ResultSet rs;
				ResultSet rs2;
				ResultSet rs3;
				rs = statement.executeQuery("SELECT * FROM products WHERE product_code = '" + productCode + "'");
				rs.next();
				String product_category_id = rs.getString("product_category_id");
				String product_sub_category_id = rs.getString("product_sub_category_id");
				
				// Get product category and sub categories based on id's.
				statement = connection.createStatement();
				rs2 = statement.executeQuery("SELECT category FROM product_category WHERE Id = " + product_category_id);
				rs2.next();
				String product_category = rs2.getString("category");
				statement = connection.createStatement();
				rs3 = statement.executeQuery("SELECT sub_category FROM product_sub_category WHERE Id = " + product_sub_category_id);
				rs3.next();
				String product_sub_category = rs3.getString("sub_category");
				
				String product_description = rs.getString("product_description");
				String paper_quantity = rs.getString("paper_quantity");
				String paper_size = rs.getString("paper_size");
				String paper_dimensions = rs.getString("paper_dimensions");
				String paper_stock = rs.getString("paper_stock");
				String paper_weight = rs.getString("paper_weight");
				String paper_sides_pages = rs.getString("paper_sides_pages");
				String costs_price = rs.getString("costs_price");
				String costs_vat = rs.getString("costs_vat");
				
				String costs_total = "";
				if(costs_vat.equals("Standard Rated")) {
					//
					double tempCosts = Double.valueOf(costs_price);
					double standardRated = (0.200 * tempCosts) + tempCosts;
					costs_total = String.valueOf(standardRated);
				} else {
					costs_total = costs_price;
				}
				
				String finalised = "1";
				String stage = "1";
				
				// Create item number based on main order no & order item position.
				String latestOrderItemPosition = String.valueOf(orderItemPosition);
				int latestOrderNoAdjustment = 3 - latestOrderItemPosition.length();
				for(int i = 0; i < latestOrderNoAdjustment; i++) {
					latestOrderItemPosition = "0" + latestOrderItemPosition;
				}
				String item_no = main_order_no + "-" + latestOrderItemPosition;
				orderItemPosition++;
				
				// Now insert new order item.
				statement = connection.createStatement();
				int noOfUpdateResults = statement.executeUpdate("INSERT INTO order_items(order_id, item_no, product_code, product_category, product_sub_category, product_description, paper_quantity, paper_size, paper_dimensions, paper_stock, paper_weight, paper_sides_pages, costs_price, costs_vat, costs_total, finalised, stage) VALUES('" + main_order_id + "', '" + item_no + "', '" + productCode + "', '" + product_category + "', '" + product_sub_category + "', '" + product_description + "', '" + paper_quantity + "', '" + paper_size + "', '" + paper_dimensions + "', '" + paper_stock + "', '" + paper_weight + "', '" + paper_sides_pages + "', '" + costs_price + "', '" + costs_vat + "', '" + costs_total + "', '" + finalised + "', '" + stage + "')", Statement.RETURN_GENERATED_KEYS);
				if(noOfUpdateResults > 0) {
					log.info("Order Item Inserted - " + product_description);
					log.info("Transaction complete at " + new Date().toString() );
				} else {
					log.info("fail - sorry, there was a problem adding the order item.");
					log.info("Transaction complete at " + new Date().toString() );
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
				log.info(e.toString());
				closeDB(connection);
				return "fail - sorry, could not retrieve product based on code passed in.";
			}
		}
		// reset order item position to 1.
		orderItemPosition = 1;
		
		log.info("Transaction complete at " + new Date().toString() );
		
		closeDB(connection);
		
		return "success";
	}
	
	public String addOrderAddress(Credentials credentials, String orderNo, List<String> productCodes, DeliveryAddress alternateDeliveryAddress, double totalCost) {
		
		log.info("\n*** addOrderAddress() invoked.\n");
		// checkDBConnection();
		Connection connection = getDBConnection();
		
		// Check credentials.
		if( !checkCredentials(credentials, connection) ) {
			log.info("\nSorry, Invalid credentials");
			closeDB(connection);
			return "fail - invalid credentials passed in";
		}
		
		log.info(credentials.getUserId());
		log.info(credentials.getUsername());
		log.info(credentials.getPassword());
		log.info("Order No is " + orderNo);
		log.info("Total Cost in is: " + totalCost);
		
		String main_order_no = "";
		String main_order_id = "";
		
		// Get main order no from order alias.
		try {
			statement = connection.createStatement();
			ResultSet rs;
			rs = statement.executeQuery("SELECT order_no, orders.Id FROM orders, order_alias WHERE orders.Id = order_alias.order_id AND order_alias.alias = '" + orderNo + "'");
			rs.next();
			main_order_no = rs.getString("order_no");
			main_order_id = rs.getString("Id");
		} catch (SQLException e) {
			log.info(e.toString());
			e.printStackTrace();
			closeDB(connection);
			return "fail - sorry, could not retrieve main order no";
		}
		
		int orderItemPosition = 1;
		
		// For each product, extract all info required before insert based on productCode.
		for (String productCode : productCodes) {
			log.info("Product code in is - " + productCode);
			
			// Use select
			try {
				statement = connection.createStatement();
				ResultSet rs;
				ResultSet rs2;
				ResultSet rs3;
				rs = statement.executeQuery("SELECT * FROM products WHERE product_code = '" + productCode + "'");
				rs.next();
				String product_category_id = rs.getString("product_category_id");
				String product_sub_category_id = rs.getString("product_sub_category_id");
				
				// Get product category and sub categories based on id's.
				statement = connection.createStatement();
				rs2 = statement.executeQuery("SELECT category FROM product_category WHERE Id = " + product_category_id);
				rs2.next();
				String product_category = rs2.getString("category");
				statement = connection.createStatement();
				rs3 = statement.executeQuery("SELECT sub_category FROM product_sub_category WHERE Id = " + product_sub_category_id);
				rs3.next();
				String product_sub_category = rs3.getString("sub_category");
				
				String product_description = rs.getString("product_description");
				String paper_quantity = rs.getString("paper_quantity");
				String paper_size = rs.getString("paper_size");
				String paper_dimensions = rs.getString("paper_dimensions");
				String paper_stock = rs.getString("paper_stock");
				String paper_weight = rs.getString("paper_weight");
				String paper_sides_pages = rs.getString("paper_sides_pages");
				String costs_price = rs.getString("costs_price");
				String costs_vat = rs.getString("costs_vat");
				
				String costs_total = "";
				if(costs_vat.equals("Standard Rated")) {
					//
					double tempCosts = Double.valueOf(costs_price);
					double standardRated = (0.200 * tempCosts) + tempCosts;
					costs_total = String.valueOf(standardRated);
				} else {
					costs_total = costs_price;
				}
				
				String finalised = "1";
				String stage = "1";
				
				// Create item number based on main order no & order item position.
				String latestOrderItemPosition = String.valueOf(orderItemPosition);
				int latestOrderNoAdjustment = 3 - latestOrderItemPosition.length();
				for(int i = 0; i < latestOrderNoAdjustment; i++) {
					latestOrderItemPosition = "0" + latestOrderItemPosition;
				}
				String item_no = main_order_no + "-" + latestOrderItemPosition;
				orderItemPosition++;
				
				// Now insert new order item.
				statement = connection.createStatement();
				int noOfUpdateResults = statement.executeUpdate("INSERT INTO order_items(order_id, item_no, product_code, product_category, product_sub_category, product_description, paper_quantity, paper_size, paper_dimensions, paper_stock, paper_weight, paper_sides_pages, costs_price, costs_vat, costs_total, finalised, stage) VALUES('" + main_order_id + "', '" + item_no + "', '" + productCode + "', '" + product_category + "', '" + product_sub_category + "', '" + product_description + "', '" + paper_quantity + "', '" + paper_size + "', '" + paper_dimensions + "', '" + paper_stock + "', '" + paper_weight + "', '" + paper_sides_pages + "', '" + costs_price + "', '" + costs_vat + "', '" + costs_total + "', '" + finalised + "', '" + stage + "')", Statement.RETURN_GENERATED_KEYS);
				if(noOfUpdateResults > 0) {
					log.info("Order Item Inserted - " + product_description);
					log.info("Transaction complete at " + new Date().toString() );
				} else {
					log.info("fail - sorry, there was a problem adding the order item.");
					log.info("Transaction complete at " + new Date().toString() );
				}
				
			} catch (SQLException e) {
				log.info(e.toString());
				e.printStackTrace();
				closeDB(connection);
				return "fail - sorry, could not retrieve product based on code passed in.";
			}
		}
		// reset order item position to 1.
		orderItemPosition = 1;
		
		// Now because this is addOrderAddress(), we need to insert the alternate address record & strip out problematic characters.
		String delivery_address_1 = Utility.escapeProblematicSQLChars(alternateDeliveryAddress.getDeliveryAddress1());
		String delivery_address_2 = Utility.escapeProblematicSQLChars(alternateDeliveryAddress.getDeliveryAddress2());
		String delivery_town_city = Utility.escapeProblematicSQLChars(alternateDeliveryAddress.getDeliveryTownCity());
		String delivery_postcode = Utility.escapeProblematicSQLChars(alternateDeliveryAddress.getDeliveryPostcode());
		String delivery_name = Utility.escapeProblematicSQLChars(alternateDeliveryAddress.getDeliveryName());
		
		// Now insert alternate order delivery address into DB.
		try {
			statement = connection.createStatement();
			log.info("Logging Alternate Delivery Address.");
			log.info("Delivery Name is: " + delivery_name);
			log.info("Delivery Address 1 is: " + delivery_address_1);
			log.info("Delivery Address 2 is: " + delivery_address_2);
			log.info("Delivery Town City is: " + delivery_town_city);
			log.info("Delivery Postcode is: " + delivery_postcode);
			int noOfUpdateResults = statement.executeUpdate("INSERT INTO order_delivery_address(order_id, delivery_address_1, delivery_address_2, delivery_town_city, delivery_postcode, delivery_name) VALUES('" + main_order_id + "', '" + delivery_address_1 + "', '" + delivery_address_2 + "', '" + delivery_town_city + "', '" + delivery_postcode + "', '" + delivery_name + "')", Statement.RETURN_GENERATED_KEYS);
			if(noOfUpdateResults > 0) {
				log.info("Alternate order delivery address Inserted");
				log.info("Transaction complete at " + new Date().toString() );
			} else {
				log.info("fail - sorry, there was a problem inserting delivery address.");
				log.info("Transaction complete at " + new Date().toString() );
			}
		} catch (SQLException e) {
			log.info(e.toString());
			e.printStackTrace();
			closeDB(connection);
			return "fail - sorry, could not insert delivery address";
		}
		
		log.info("Transaction complete at " + new Date().toString() );
		
		closeDB(connection);
		
		return "success";
	}

	public List<Product> getCatalogue(Credentials credentials) {
		
		Connection connection = getDBConnection();
		
		String productCategoryId;
		String productSubCategoryId;
		String productCategory;
		String productSubCategory;
		String productCode;
		String paperQuantity;
		String paperSize;
		String paperDimensions;
		String paperWeight;
		String paperStock;
		String paperSidesPages;
		String costsPrice;
		String costsVat;
		String production;
		String accreditation;
		String delivery;
		String laminate_s_s;
		String met_ink_s_s;
		String four_hundred_gsm_matt;
		String glueAndAssemble;
		String bcUpgradeDS;
		String dispatchedWithin24Hours;
		String productDescription;
		String productOrder;
		String image;
		
		log.info("\n*** getCatalogue() invoked.\n");
		// checkDBConnection();
		// Connection connection = getDBConnection();
		
		log.info(credentials.getUserId());
		log.info(credentials.getUsername());
		log.info(credentials.getPassword());
		log.info("");
		
		// Check credentials.
		if( !checkCredentials(credentials, connection) ) {
			log.info("\nSorry, Invalid credentials");
			closeDB(connection);
			return null;
		}
		
		List<Product> products = new ArrayList<Product>();
		// products.add(new Product());
		// products.add(new Product());
		
		try {
			Statement statement = connection.createStatement();
			ResultSet rs;
			ResultSet rs2;
			ResultSet rs3;
			
			// Define default product catalogue as peanut print.
			// 2 = peanut print. 3 = inkshop online.
			// Work out which catalogue to return based on user.
			String productCatalogueId = "2";
			if( credentials.getUsername().equals("tictoc") ) {
				productCatalogueId = "2";
			} else if( credentials.getUsername().equals("inkshoponline") ) {
				productCatalogueId = "3";
			}
			
			rs = statement.executeQuery("SELECT Id, product_category_id, product_sub_category_id, product_order, product_code, paper_quantity, paper_size, paper_dimensions, paper_weight, paper_stock, paper_sides_pages, costs_price, costs_vat, production, accreditation, delivery, laminate_s_s, met_ink_s_s, 400gsm_matt, glue_and_assemble, bc_upgrade_ds, dispatch_within_24_hours, product_description, product_catalogue_id, image, date_time, last_updated FROM products WHERE product_catalogue_id = " + productCatalogueId);
			
			int productCount = 0;
			
			// Trial this
			Statement statement2 = connection.createStatement();
			Statement statement3 = connection.createStatement();
			
			while(rs.next()) {
				log.info("Printing Product");
				log.info("----------------\n");
				
				productCode = rs.getString("product_code");
				paperQuantity = rs.getString("paper_quantity");
				paperSize = rs.getString("paper_size");
				paperDimensions = rs.getString("paper_dimensions");
				paperWeight = rs.getString("paper_weight");
				paperStock = rs.getString("paper_stock");
				paperSidesPages = rs.getString("paper_sides_pages");
				costsPrice = rs.getString("costs_price");
				costsVat = rs.getString("costs_vat");
				production = rs.getString("production");
				accreditation = rs.getString("accreditation");
				delivery = rs.getString("delivery");
				laminate_s_s = rs.getString("laminate_s_s");
				met_ink_s_s = rs.getString("met_ink_s_s");
				four_hundred_gsm_matt = rs.getString("400gsm_matt");
				glueAndAssemble = rs.getString("glue_and_assemble");
				bcUpgradeDS = rs.getString("bc_upgrade_ds");
				dispatchedWithin24Hours = rs.getString("dispatch_within_24_hours");
				productDescription = rs.getString("product_description");
				productOrder = rs.getString("product_order");
				image = rs.getString("image");
				
				// Now get product category and product sub categories.
				productCategoryId = rs.getString("product_category_id");
				productSubCategoryId = rs.getString("product_sub_category_id");
				
				// statement = connection.createStatement();
				rs2 = statement2.executeQuery("SELECT category FROM product_category WHERE Id = " + productCategoryId);
				rs2.next();
				productCategory = rs2.getString("category");
				
				// statement = connection.createStatement();
				rs3 = statement3.executeQuery("SELECT sub_category FROM product_sub_category WHERE Id = " + productSubCategoryId);
				rs3.next();
				productSubCategory = rs3.getString("sub_category");
				
				Product product = new Product();
				product.setProductCategory(productCategory);
				product.setProductSubCategory(productSubCategory);
				product.setProductCode(productCode);
				product.setPaperQuantity(paperQuantity);
				product.setPaperSize(paperSize);
				product.setPaperDimensions(paperDimensions);
				product.setPaperWeight(paperWeight);
				product.setPaperStock(paperStock);
				product.setPaperSidesPages(paperSidesPages);
				product.setCostsPrice(costsPrice);
				product.setCostsVat(costsVat);
				product.setProduction(production);
				product.setAccreditation(accreditation);
				product.setDelivery(delivery);
				product.setLaminate_s_s(laminate_s_s);
				product.setMet_ink_s_s(met_ink_s_s);
				product.setFour_hundred_gsm_matt(four_hundred_gsm_matt);
				product.setGlueAndAssemble(glueAndAssemble);
				product.setBcUpgrade(bcUpgradeDS);
				product.setDispatchedWithin24Hours(dispatchedWithin24Hours);
				product.setProductDescription(productDescription);
				product.setProductOrder(productOrder);
				product.setImage(image);
				product.setMarker("added");
				
				products.add(product);
				productCount++;
				
				log.info("Product Added to list. Count is " + productCount);
				log.info("productCategory " + productCategory);
				log.info("productSubCategory " + productSubCategory);
				log.info("productCode " + productCode);
				log.info("paperQuantity " + paperQuantity);
				log.info("paperSize " + paperSize);
				log.info("paperDimensions " + paperDimensions);
				log.info("paperWeight " + paperWeight);
				log.info("paperStock " + paperStock);
				log.info("paperSidesPages " + paperSidesPages);
				log.info("costsPrice " + costsPrice);
				log.info("costsVat " + costsVat);
				log.info("production " + production);
				log.info("accreditation " + accreditation);
				log.info("delivery " + delivery);
				log.info("laminate_s_s " + laminate_s_s);
				log.info("met_ink_s_s " + met_ink_s_s);
				log.info("four_hundred_gsm_matt " + four_hundred_gsm_matt);
				log.info("glueAndAssemble " + glueAndAssemble);
				log.info("bcUpgradeDS " + bcUpgradeDS);
				log.info("dispatchedWithin24Hours " + dispatchedWithin24Hours);
				log.info("productDescription " + productDescription);
				log.info("productOrder " + productOrder);
				log.info("image " + image);
				
				rs2.close();
				rs3.close();
			}
			
			// log.info(testString);
			log.info("");
			rs.close();
			statement.close();
			connection.close();
		} catch (Exception e) {
			log.info("There may be a problem closing either statement or result set\n\n" + e.getMessage());
			log.info(e);
			log.error("error", e);
			e.printStackTrace();
		}
		
		log.info("Transaction complete at " + new Date().toString() );
		
		checkMemory();
		
		// closeDB(connection);
		
		return products;
	}

	public List<Product> getCatalogueDate(Credentials credentials, Calendar date) {
		
		log.info("\n*** getCatalogue(overloaded with date) invoked.\n");
		return getCatalogue(credentials);
		
	}
	
	public boolean checkCredentials(Credentials credentials, Connection connection) {
		
		int userId = credentials.getUserId();
		String userName = credentials.getUsername();
		String password = credentials.getPassword();
		String userNameIn;
		String passwordIn;
		String encPassword;
		
		// Get user record from database based on userId.
		try {
			statement = connection.createStatement();
			ResultSet rs;
			rs = statement.executeQuery("SELECT member_username, member_password FROM hr_table WHERE employee_number = " + userId);
			rs.next();
			userNameIn = rs.getString("member_username");
			passwordIn = rs.getString("member_password");
			
			// Encrypt and compare passed in password and username.
			// If both match, then return true.
			statement = connection.createStatement();
			rs = statement.executeQuery("SELECT SHA('" + password + "') AS encPassword");
			rs.next();
			encPassword = rs.getString("encPassword");
			
			if( (userName.equals(userNameIn)) && (passwordIn.equals(encPassword)) ) {
				return true;
			} else {
				return false;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		log.info("Transaction complete at " + new Date().toString() );
		
		return false;
	}
	
	public void checkDBConnection() {
		
		checkMemory();
		
		String url = null;
		String dbName = null;
		String driver  = null;
		String userName = null;
		String dbPassword = null;
		
		if( this.environment.equals("live") ) {
			url = "jdbc:mysql://localhost:3306/";
			dbName = "inkshopcrm";
			driver  = "com.mysql.jdbc.Driver";
			userName = "inkshopcrm1";
			dbPassword = "Inkshopcrm1";
		}
		else if( this.environment.equals("test") ) {	
			url = "jdbc:mysql://localhost:3306/";
			dbName = "testinkshopcrm";
			driver  = "com.mysql.jdbc.Driver";
			userName = "inkshopcrm3";
			dbPassword = "Inkshopcrm3";
		}
		
		
		try {
			if(connection.isClosed() || !connection.isValid(0)) {
				connection.close();
				Class.forName(driver).newInstance();
				connection = DriverManager.getConnection(url+dbName+"?autoReconnect=true",userName,dbPassword);
				log.info("Good to go and connected to database...\n");
			} else {
				log.info("*** Check DB connection OK...");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void closeDB() {
		
		checkMemory();
		
		try {
			connection.close();
			log.info("DB Connection Closed...");
		} catch (SQLException e) {
			log.info("There was a problem\n\n" + e.getMessage());
			log.info(e);
			log.error("error", e);
			e.printStackTrace();
		} catch(Exception e) {
			log.info("There was a problem\n\n" + e.getMessage());
			log.info(e);
			log.error("error", e);
			e.printStackTrace();
		}
	}
	
	public void checkMemory() {
		
		Runtime.getRuntime().gc();
        log.info("\n*** Total memory is " + Runtime.getRuntime().totalMemory());
        log.info("*** Max memory is " + Runtime.getRuntime().maxMemory());
        log.info("*** Free memory is " + Runtime.getRuntime().freeMemory() + "\n");
	}
	
	public Connection getDBConnection() {
		Connection connection = null;
		try {
			connection = dataSource.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}
	
	public void closeDB(Connection connection) {
		
		checkMemory();
		
		try {
			connection.close();
			log.info("DB Connection Closed...");
		} catch (SQLException e) {
			log.info("There was a problem\n\n" + e.getMessage());
			log.info(e);
			log.error("error", e);
			e.printStackTrace();
		} catch(Exception e) {
			log.info("There was a problem\n\n" + e.getMessage());
			log.info(e);
			log.error("error", e);
			e.printStackTrace();
		}
	}
}