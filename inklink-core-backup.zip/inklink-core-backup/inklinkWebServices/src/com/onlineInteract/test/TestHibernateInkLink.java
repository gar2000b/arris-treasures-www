package com.onlineInteract.test;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

import com.onlineInteract.dataModel.entities.ProductEntity;
import com.onlineInteract.service.InkLinkService;

public class TestHibernateInkLink {
	
	   public static void main(String[] args) {
	         SessionFactory factory = new AnnotationConfiguration().configure().buildSessionFactory();
	         
	         InkLinkService.setFactory(factory);
	         
	         InkLinkService.getProduct(Integer.valueOf(1));
	         InkLinkService.getProduct(Integer.valueOf(2));
	         InkLinkService.getProduct(Integer.valueOf(3));
	         
	         List<ProductEntity> results = InkLinkService.getProductCatalogue(2);
	         
	         for (ProductEntity productEntity : results) {
				System.out.println("Product Code is " + productEntity.getProductCode());
	         }
	         System.out.println("*** Total Products returned is " + results.size());
	   }
}
