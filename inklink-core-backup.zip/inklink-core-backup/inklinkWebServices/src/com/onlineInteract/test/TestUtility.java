package com.onlineInteract.test;

import com.onlineInteract.utility.Utility;

public class TestUtility {

	public static void main(String args[]) {
	
		String test = "Test to escape inverted comma's and backslashes \\ and quotes \" - doesn't affect postcodes G741DD";
		test = Utility.escapeProblematicSQLChars(test);
		System.out.println(test);
		
		String test2 = null;
		test2 = Utility.escapeProblematicSQLChars(test2);
		System.out.println("test2 is " + test2);
	}
}
