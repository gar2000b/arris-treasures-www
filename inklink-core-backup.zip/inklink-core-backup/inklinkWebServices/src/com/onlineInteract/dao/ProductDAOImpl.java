package com.onlineInteract.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.onlineInteract.dataModel.entities.ProductEntity;
import com.onlineInteract.service.InkLinkService;

public class ProductDAOImpl {

	public static ProductEntity getProduct(Integer id) {
		
		Session session = InkLinkService.getFactory().openSession();
		session.beginTransaction();
		
        ProductEntity product = (ProductEntity) session.get(ProductEntity.class, id);
        if(product != null) {
       	 System.out.println("Product with code of " + product.getProductCode());
        }
        else {
       	 System.out.println("Product not found for id " + id);
        }

        session.getTransaction().commit();
        session.close();

        // System.out.println("Are we binding to Hibernate? :)");
		
		return product;
	}
	
	public static List<ProductEntity> getProductCatalogue(Integer catalogueId) {
		
		Session session = InkLinkService.getFactory().openSession();
		session.beginTransaction();
		Query query = session.createQuery("from ProductEntity where productCatalogueId = " + catalogueId);
		@SuppressWarnings("unchecked")
		List<ProductEntity> results = query.list();
        session.getTransaction().commit();
        session.close();

        System.out.println("Returning Product Catalogue");
		return results;
	}
}
