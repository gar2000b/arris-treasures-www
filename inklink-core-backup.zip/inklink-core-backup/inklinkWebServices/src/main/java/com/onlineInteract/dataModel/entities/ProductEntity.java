package com.onlineInteract.dataModel.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "products")
public class ProductEntity {

	private Integer id;
	private Integer productCatalogueId;
	private String productCode;
//	private String productCategory;
//	private String productSubCategory;
	private String productDescription;
	private String productOrder;
	private Integer paperQuantity;
	private String paperSize;
	private String paperDimensions;
	private String paperStock;
	private String paperWeight;
	private String paperSidesPages;
	private Double costsPrice;
	private String costsVat;
	private String production;
	private String accreditation;
	private String delivery;
	private String laminate_s_s;
	private String met_ink_s_s;
	private String four_hundred_gsm_matt;
	private String glueAndAssemble;
	private String bcUpgrade;
	private String dispatchedWithin24Hours;
	private String image;
	
	public ProductEntity() {}

	@Id
	@GeneratedValue
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	@Column(name = "product_catalogue_id", nullable = false, length = 11)
	public Integer getProductCatalogueId() {
		return productCatalogueId;
	}

	public void setProductCatalogueId(Integer productCatalogueId) {
		this.productCatalogueId = productCatalogueId;
	}

	@Column(name = "product_code", nullable = false, length = 24)
	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

//	public String getProductCategory() {
//		return productCategory;
//	}
//
//	public void setProductCategory(String productCategory) {
//		this.productCategory = productCategory;
//	}
//
//	public String getProductSubCategory() {
//		return productSubCategory;
//	}
//
//	public void setProductSubCategory(String productSubCategory) {
//		this.productSubCategory = productSubCategory;
//	}

	@Column(name = "product_description", nullable = true, length = 500)
	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	@Column(name = "product_order", nullable = false, length = 255)
	public String getProductOrder() {
		return productOrder;
	}

	public void setProductOrder(String productOrder) {
		this.productOrder = productOrder;
	}

	@Column(name = "paper_quantity", nullable = true, length = 11)
	public Integer getPaperQuantity() {
		return paperQuantity;
	}

	public void setPaperQuantity(Integer paperQuantity) {
		this.paperQuantity = paperQuantity;
	}

	@Column(name = "paper_size", nullable = false, length = 50)
	public String getPaperSize() {
		return paperSize;
	}

	public void setPaperSize(String paperSize) {
		this.paperSize = paperSize;
	}

	@Column(name = "paper_dimensions", nullable = true, length = 50)
	public String getPaperDimensions() {
		return paperDimensions;
	}

	public void setPaperDimensions(String paperDimensions) {
		this.paperDimensions = paperDimensions;
	}

	@Column(name = "paper_stock", nullable = false, length = 50)
	public String getPaperStock() {
		return paperStock;
	}

	public void setPaperStock(String paperStock) {
		this.paperStock = paperStock;
	}

	@Column(name = "paper_weight", nullable = true, length = 50)
	public String getPaperWeight() {
		return paperWeight;
	}

	public void setPaperWeight(String paperWeight) {
		this.paperWeight = paperWeight;
	}

	@Column(name = "paper_sides_pages", nullable = false, length = 50)
	public String getPaperSidesPages() {
		return paperSidesPages;
	}

	public void setPaperSidesPages(String paperSidesPages) {
		this.paperSidesPages = paperSidesPages;
	}

	@Column(name = "costs_price", nullable = true, precision=10, scale=2)
	public Double getCostsPrice() {
		return costsPrice;
	}

	public void setCostsPrice(Double costsPrice) {
		this.costsPrice = costsPrice;
	}

	@Column(name = "costs_vat", nullable = false, length = 30)
	public String getCostsVat() {
		return costsVat;
	}

	public void setCostsVat(String costsVat) {
		this.costsVat = costsVat;
	}

	@Column(name = "production", nullable = false, length = 255)
	public String getProduction() {
		return production;
	}

	public void setProduction(String production) {
		this.production = production;
	}

	@Column(name = "accreditation", nullable = false, length = 255)
	public String getAccreditation() {
		return accreditation;
	}

	public void setAccreditation(String accreditation) {
		this.accreditation = accreditation;
	}

	@Column(name = "delivery", nullable = false, length = 255)
	public String getDelivery() {
		return delivery;
	}

	public void setDelivery(String delivery) {
		this.delivery = delivery;
	}

	@Column(name = "laminate_s_s", nullable = false)
	public String getLaminate_s_s() {
		return laminate_s_s;
	}

	public void setLaminate_s_s(String laminate_s_s) {
		this.laminate_s_s = laminate_s_s;
	}

	@Column(name = "met_ink_s_s", nullable = false)
	public String getMet_ink_s_s() {
		return met_ink_s_s;
	}

	public void setMet_ink_s_s(String met_ink_s_s) {
		this.met_ink_s_s = met_ink_s_s;
	}

	// 400gsm_matt - for mySQL.
	@Column(name = "fourhundredgsm_matt", nullable = false)
	public String getFour_hundred_gsm_matt() {
		return four_hundred_gsm_matt;
	}

	public void setFour_hundred_gsm_matt(String four_hundred_gsm_matt) {
		this.four_hundred_gsm_matt = four_hundred_gsm_matt;
	}

	@Column(name = "glue_and_assemble", nullable = false)
	public String getGlueAndAssemble() {
		return glueAndAssemble;
	}

	public void setGlueAndAssemble(String glueAndAssemble) {
		this.glueAndAssemble = glueAndAssemble;
	}

	@Column(name = "bc_upgrade_ds", nullable = false)
	public String getBcUpgrade() {
		return bcUpgrade;
	}

	public void setBcUpgrade(String bcUpgrade) {
		this.bcUpgrade = bcUpgrade;
	}

	@Column(name = "dispatch_within_24_hours", nullable = false, length = 255)
	public String getDispatchedWithin24Hours() {
		return dispatchedWithin24Hours;
	}

	public void setDispatchedWithin24Hours(String dispatchedWithin24Hours) {
		this.dispatchedWithin24Hours = dispatchedWithin24Hours;
	}

	@Column(name = "image", nullable = false, length = 255)
	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}
	
}
