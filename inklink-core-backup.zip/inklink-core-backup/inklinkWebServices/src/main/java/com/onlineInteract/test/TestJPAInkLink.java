package com.onlineInteract.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.onlineInteract.dataModel.entities.ProductEntity;

public class TestJPAInkLink {
	public static void main(String[] args) {
		
//		Properties properties = new Properties();
//		properties.put("eclipselink.persistencexml", "persistence.xml");
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpatest");
		EntityManager em = emf.createEntityManager();
		ProductEntity product = em.find(ProductEntity.class, 1);
		System.out.println("*** Product Code is " + product.getProductCode());
		em.close();
		emf.close();
	}
}
