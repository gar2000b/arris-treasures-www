package com.onlineInteract.dataModel.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "artist")
public class Artist {

	private Integer Id;
	private String firstname;
	private String lastname;
	private List<CD> cds;

	public Artist() {
	}

	@Id
	@GeneratedValue
	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	@Column(name = "firstname", nullable = false, length = 50)
	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	@Column(name = "lastname", nullable = false, length = 50)
	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	@ManyToMany
	@JoinTable(name = "artist_cd", 
			joinColumns = @JoinColumn(name = "artist_id"), 
			inverseJoinColumns = @JoinColumn(name = "cd_id"))
	public List<CD> getCds() {
		return cds;
	}

	public void setCds(List<CD> cds) {
		this.cds = cds;
	}
}
