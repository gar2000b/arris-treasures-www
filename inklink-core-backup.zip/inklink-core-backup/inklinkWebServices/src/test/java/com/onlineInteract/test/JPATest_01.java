package com.onlineInteract.test;

import static org.junit.Assert.assertNotNull;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.onlineInteract.dataModel.entities.Address;
import com.onlineInteract.dataModel.entities.Artist;
import com.onlineInteract.dataModel.entities.CD;
import com.onlineInteract.dataModel.entities.Customer;
import com.onlineInteract.dataModel.entities.Item;
import com.onlineInteract.dataModel.entities.Order;
import com.onlineInteract.dataModel.entities.ProductEntity;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class JPATest_01 {

	private static EntityManagerFactory emf;
	private static EntityManager em;
	private static EntityTransaction tx;

	@BeforeClass
	public static void initEntityManager() throws Exception {
		emf = Persistence.createEntityManagerFactory("jpatest");
		em = emf.createEntityManager();
	}

	@AfterClass
	public static void closeEntityManager() throws SQLException {
		em.close();
		emf.close();
	}

	@Before
	public void initTransaction() {
		System.out.println("Init Transaction called.");
		tx = em.getTransaction();
	}

	/**
	 * This test demonstrates basic persistence against one entity.
	 */
	@Test
	public void test_1a_createProduct() {
		ProductEntity product = new ProductEntity();
		product.setProductCode("abcdef");
		product.setCostsPrice(1234.56);
		product.setImage("image1");
		product.setProductCatalogueId(1);
		product.setProductOrder("1");
		product.setPaperSize("1mm");
		product.setPaperStock("stock");
		product.setPaperSidesPages("2 sides");
		product.setCostsVat("zero rated");
		product.setProduction("production");
		product.setAccreditation("accreditation");
		product.setDelivery("A");
		product.setLaminate_s_s("setLaminate_s_s");
		product.setMet_ink_s_s("setMet_ink_s_s");
		product.setFour_hundred_gsm_matt("four_hundred_gsm_matt");
		product.setGlueAndAssemble("Y");
		product.setBcUpgrade("Y");
		product.setDispatchedWithin24Hours("Y");

		// Persists the product to the DB
		tx.begin();
		em.persist(product);
		tx.commit();
		System.out.println("Product Id = " + product.getId().toString());
		assertNotNull("ID should not be null", product.getId());
	}

	/**
	 * This test demonstrates basic persistence against another entity and
	 * proves that the sequence is being incremented.
	 */
	@Test
	public void test_1b_createAnotherProduct() {
		ProductEntity product = new ProductEntity();
		product.setProductCode("abcdef");
		product.setCostsPrice(1234.56);
		product.setImage("image1");
		product.setProductCatalogueId(1);
		product.setProductOrder("1");
		product.setPaperSize("1mm");
		product.setPaperStock("stock");
		product.setPaperSidesPages("2 sides");
		product.setCostsVat("zero rated");
		product.setProduction("production");
		product.setAccreditation("accreditation");
		product.setDelivery("A");
		product.setLaminate_s_s("setLaminate_s_s");
		product.setMet_ink_s_s("setMet_ink_s_s");
		product.setFour_hundred_gsm_matt("four_hundred_gsm_matt");
		product.setGlueAndAssemble("Y");
		product.setBcUpgrade("Y");
		product.setDispatchedWithin24Hours("Y");

		// Persists the product to the DB
		tx.begin();
		em.persist(product);
		tx.commit();
		System.out.println("Product Id = " + product.getId().toString());
		assertNotNull("ID should not be null", product.getId());
	}

	/**
	 * This test demonstrates basic persistence against one entity which will be
	 * used again in our oneToMany relationship test further down.
	 */
	@Test
	public void test_1c_createAnItem() {
		Item item = new Item();
		item.setName("Mega Drive");
		item.setPrice(199.99);

		// Persists the product to the DB
		tx.begin();
		em.persist(item);
		tx.commit();
		System.out.println("Item Id = " + item.getId().toString());
		assertNotNull("ID should not be null", item.getId());
	}

	/**
	 * This test demonstrates a oneToOne relationship.
	 */
	@Test
	public void test_1d_createCustomerAndAddress() {
		Customer customer = new Customer();
		customer.setName("Gary Black");
		Address address = new Address();
		address.setAddress1("35 Murchison Drive");
		address.setAddress2("Westwood");
		address.setTownCity("East Kilbride");
		address.setPostcode("G75 8HF");
		address.setCustomer(customer);
		customer.setAddress(address);

		tx.begin();
		em.persist(customer);
		em.persist(address);
		tx.commit();

		System.out.println("Customer Id is " + customer.getId() + " name is "
				+ customer.getName());
		System.out.println("Address Id is " + customer.getAddress().getId()
				+ " line 1 is " + customer.getAddress().getAddress1());
	}

	/**
	 * This test demonstrates a oneToMany / manyToOne relationship.
	 */
	@Test
	public void test_1e_createAnOrder() {

		Item item1 = new Item();
		item1.setName("NES");
		item1.setPrice(149.99);
		Item item2 = new Item();
		item2.setName("Playstation");
		item2.setPrice(299.99);
		Item item3 = new Item();
		item3.setName("XBox");
		item3.setPrice(249.99);

		// Note: for a bi-directional relationship, we have to ensure we 'set'
		// both sides. in our case, remember to assign the order to each of the
		// items.
		Order order = new Order();
		List<Item> items = new ArrayList<Item>();
		item1.setOrder(order);
		item2.setOrder(order);
		item3.setOrder(order);
		items.add(item1);
		items.add(item2);
		items.add(item3);
		order.setItems(items);
		order.setDate(new Date());

		// Persists the product to the DB
		tx.begin();
		em.persist(item1);
		em.persist(item2);
		em.persist(item3);
		em.persist(order);
		tx.commit();

		for (Item item : order.getItems()) {
			System.out.println("Item Id is " + item.getId() + " name = "
					+ item.getName());
			System.out.println("* This items order is "
					+ item.getOrder().getId());
		}
		System.out.println("Order Id is " + order.getId() + " date = "
				+ order.getDate());
	}

	/**
	 * This test demonstrates a manyToMany relationship. We demonstrate this by
	 * creating x3 CDs and x2 Artists. CDs can have multiple artists and artists
	 * can have multiple CDs.
	 */
	@Test
	public void test_1f_createCDsArtists() {

		// Create all the CDs and assign all the scaler values.
		CD cd1 = new CD();
		cd1.setTitle("Now 51");
		cd1.setDescription("Big Album");
		cd1.setPrice(19.99);
		CD cd2 = new CD();
		cd2.setTitle("Now 52");
		cd2.setDescription("Bigger Album");
		cd2.setPrice(22.99);
		CD cd3 = new CD();
		cd3.setTitle("Queens Greatest Hits");
		cd3.setDescription("The most amazing Album EVER!!!");
		cd3.setPrice(24.99);

		// Create the artists and assign the scaler values.
		Artist artist1 = new Artist();
		artist1.setFirstname("Mega");
		artist1.setLastname("Mix");
		Artist artist2 = new Artist();
		artist2.setFirstname("Queen");
		artist2.setLastname("Band");

		// Create the artists collection and add artists.
		List<Artist> artists = new ArrayList<Artist>();
		artists.add(artist1);
		artists.add(artist2);

		// Create the CDs collection and add the CDs.
		List<CD> cds = new ArrayList<CD>();
		cds.add(cd1);
		cds.add(cd2);

		// Set the bi-directional assignments - artists.
		artist1.setCds(cds);
		List<CD> queenCDList = new ArrayList<CD>();
		queenCDList.add(cd3);
		artist2.setCds(queenCDList);

		// Set the bi-directional assignments - CDs.
		cd1.setArtists(artists);
		cd2.setArtists(artists);
		List<Artist> queenArtistList = new ArrayList<Artist>();
		queenArtistList.add(artist2);
		cd3.setArtists(queenArtistList);

		// Persist all entities to the DB.
		tx.begin();
		em.persist(cd1);
		em.persist(cd2);
		em.persist(cd3);
		em.persist(artist1);
		em.persist(artist2);
		tx.commit();

		// Print out all the information:
		System.out.println("");

		// CD1
		System.out.println("CD1 is called " + cd1.getTitle()
				+ " it has an Id of " + cd1.getId() + " and a description: "
				+ cd1.getDescription() + " it costs: " + cd1.getPrice()
				+ " and has the following artists: ");
		for (Artist artist : cd1.getArtists()) {
			System.out.println("#" + artist.getId() + ". "
					+ artist.getFirstname() + " " + artist.getLastname());
		}
		System.out.println("");

		// CD2
		System.out.println("CD2 is called " + cd2.getTitle()
				+ " it has an Id of " + cd2.getId() + " and a description: "
				+ cd2.getDescription() + " it costs: " + cd2.getPrice()
				+ " and has the following artists: ");
		for (Artist artist : cd2.getArtists()) {
			System.out.println("#" + artist.getId() + ". "
					+ artist.getFirstname() + " " + artist.getLastname());
		}
		System.out.println("");

		// CD3
		System.out.println("CD3 is called " + cd3.getTitle()
				+ " it has an Id of " + cd3.getId() + " and a description: "
				+ cd3.getDescription() + " it costs: " + cd3.getPrice()
				+ " and has the following artists: ");
		for (Artist artist : cd3.getArtists()) {
			System.out.println("#" + artist.getId() + ". "
					+ artist.getFirstname() + " " + artist.getLastname());
		}
		System.out.println("");

		// Artist 1
		System.out.println("Artist1 is called " + artist1.getFirstname() + " "
				+ artist1.getLastname() + " and has an Id of "
				+ artist1.getId() + " and has the following CDs: ");
		for (CD cd : artist1.getCds()) {
			System.out.println("#" + cd.getId() + ". " + cd.getTitle());
		}
		System.out.println("");

		// Artist 2
		System.out.println("Artist2 is called " + artist2.getFirstname() + " "
				+ artist2.getLastname() + " and has an Id of "
				+ artist2.getId() + " and has the following CDs: ");
		for (CD cd : artist2.getCds()) {
			System.out.println("#" + cd.getId() + ". " + cd.getTitle());
		}
		System.out.println("");
	}
	
	/**
	 * Retrieve an item from the DB.
	 */
	@Test
	public void test_1g_retrieveAnItem() {
		
		System.out.println();
		Item item = em.find(Item.class, 7);
		System.out.println("The Item (with Id of 7) retrieved was: " + item.getName());
	}
}
